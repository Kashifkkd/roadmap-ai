"use client";

import React, { useState } from "react";
import { Plus, GripVertical, Expand, Trash2 } from "lucide-react";
// Dropdown removed: Edit, Browse Images were here; only delete (trash) is shown on the card.
// import { MoreVertical, Pencil, ImageIcon } from "lucide-react";
// import AssetPicker from "./AssetPicker";
import GradientLoader from "@/components/ui/GradientLoader";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

// Strip all HTML to plain text only (no bold, italic, or line breaks)
function stripHtmlToPlainText(html) {
  if (!html || typeof html !== "string") return html || "";
  return html
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Plain-text snippet for the card body area — schemas differ by screen type. */
function getScreenCardContentSnippet(screen) {
  const content = screen?.screenContents?.content || {};
  const formData = screen?.formData || {};
  const contentType = screen?.screenContents?.contentType;

  if (contentType === "action" || contentType === "actions") {
    return (
      content.text ||
      formData.text ||
      formData.actionDescription ||
      content.body ||
      formData.body ||
      ""
    );
  }

  const generic =
    content.body ||
    formData.body ||
    content.keyLearning ||
    formData.keyLearning ||
    content.key_learning ||
    formData.key_learning ||
    "";
  if (generic) return generic;

  if (contentType === "assessment") {
    const title = content.title || "";
    const first = content.questions?.[0];
    const qRaw =
      first &&
      (typeof first === "object"
        ? first.text || first.question
        : String(first));
    return [title, qRaw].filter(Boolean).join(" — ");
  }

  if (
    contentType === "social_discussion" ||
    contentType === "socialDiscussion" ||
    contentType === "social"
  ) {
    return (
      content.question ||
      formData.question ||
      content.body ||
      formData.body ||
      content.title ||
      formData.title ||
      ""
    );
  }

  if (contentType === "reflection") {
    return (
      content.prompt ||
      formData.prompt ||
      content.reflectionPrompt ||
      formData.reflectionPrompt ||
      content.body ||
      formData.body ||
      ""
    );
  }

  if (
    contentType === "mcq" ||
    contentType === "poll" ||
    contentType === "poll_mcq" ||
    contentType === "pollMcq" ||
    contentType === "force_rank" ||
    contentType === "forceRank" ||
    contentType === "linear"
  ) {
    return (
      content.question ||
      formData.question ||
      content.body ||
      formData.body ||
      content.title ||
      formData.title ||
      ""
    );
  }

  if (contentType === "miniApp" || contentType === "miniapp") {
    return (
      content.heading ||
      formData.title ||
      screen.title ||
      ""
    );
  }

  return "";
}

/**
 * Resolves the best available preview image URL for a screen card.
 * Priority:
 *   1. screen.assets[] — first entry with type === "image"
 *   2. screen.screenContents.content.media — if type === "image"
 *   3. screen.thumbnail (legacy fallback)
 */
function getPreviewImageUrl(screen) {
  const imageAsset = (screen?.assets || []).find(
    (a) =>
      a &&
      typeof a === "object" &&
      (a.type === "image" || a.asset_type === "image") &&
      (a.url || a.ImageUrl)
  );
  if (imageAsset) return imageAsset.url || imageAsset.ImageUrl;

  const media = screen?.screenContents?.content?.media;
  if (media?.type === "image" && media?.url) return media.url;

  return screen?.thumbnail || null;
}

function shouldShowScreenCardImage(screen) {
  const contentType = screen?.screenContents?.contentType;
  const content = screen?.screenContents?.content || {};

  if (
    contentType === "content" ||
    contentType === "reflection" ||
    contentType === "habits" ||
    contentType === "managerEmail" ||
    contentType === "managerEmail" ||
    contentType === "accountabilityPartnerEmail" ||
    contentType === "accountabilityPartnerEmail"
  ) {
    return true;
  }

  if (contentType === "notifications") {
    return content.media?.type !== "none";
  }

  return false;
}

export default function ScreenCard({
  screen,
  chapter,
  selectedScreen,
  index,
  isGeneratingImages,
  onDragStart,
  onDragEnd,
  onDragOver,
  onDrop,
  onClick,
  onAddScreen,
  onRequestDeleteScreen,
  isDeleting = false,
}) {
  const [showAddButton, setShowAddButton] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleRequestDelete = (e) => {
    e.stopPropagation();
    if (isDeleting) return;
    onRequestDeleteScreen?.(screen.id);
  };

  const showImagePreview = shouldShowScreenCardImage(screen);
  const previewImageUrl = getPreviewImageUrl(screen);
  const hasExistingThumbnail = !!(
    previewImageUrl &&
    previewImageUrl !== "/noImage.png" &&
    previewImageUrl !== "/error-img.png"
  );

  const AddButton = ({ position, insertIndex }) => (
    <div
      className={`absolute ${position === "left" ? "-left-4" : "-right-4"
        } top-1/4 transform -translate-y-1/2 z-10`}
    >
      <button
        onClick={(e) => {
          e.stopPropagation();
          onAddScreen(insertIndex);
        }}
        className=" bg-primary-700 text-white rounded-full p-2 shadow-lg transition-all"
      >
        <Plus style={{ width: "1.25em", height: "1.25em" }} />
      </button>
    </div>
  );
  return (
    <div
      className="relative"
      onMouseEnter={() => setShowAddButton(true)}
      onMouseLeave={() => setShowAddButton(false)}
    >
      <div
        draggable
        onDragStart={(e) => onDragStart(e, index)}
        onDragEnd={onDragEnd}
        onDragOver={onDragOver}
        onDrop={(e) => onDrop(e, index)}
        onClick={() => onClick(screen)}
        className={`rounded-lg p-1.5 sm:p-2 flex flex-col justify-between items-center gap-1 sm:gap-1 text-xs
          shrink-0 shadow-sm hover:shadow-md cursor-pointer 
          border border-transparent hover:border-primary-600
          transition-all duration-300 ease-in-out
          ${selectedScreen?.id === screen.id
            ? "bg-primary-700 hover:bg-primary-600 min-w-35 sm:min-w-37.5 max-w-37.5 sm:max-w-45"
            : "bg-gray-100 hover:bg-primary-100 min-w-27.5 sm:min-w-37.5 max-w-37.5 sm:max-w-37.5"
          }
        `}
      >
        <div className="w-full flex justify-between items-center gap-2 text-xs">
          <div className="flex justify-between items-center gap-1 w-full">
            <div className="flex flex-col items-center">
              <div
                className={`flex items-center justify-between font-medium w-full transition-colors duration-300 ${selectedScreen?.id === screen.id
                    ? "text-white"
                    : "text-gray-700"
                  }`}
              >
                <span>Screen {index + 1}</span>
                {onRequestDeleteScreen && (
                  <button
                    type="button"
                    onClick={handleRequestDelete}
                    disabled={isDeleting}
                    className={`p-0.5 rounded-md transition-colors duration-200 shrink-0 inline-flex items-center justify-center min-w-[1.25em] min-h-[1.25em] ${selectedScreen?.id === screen.id
                        ? "text-white/70 hover:text-white hover:bg-white/10 disabled:opacity-60"
                        : "text-gray-400 hover:text-red-600 hover:bg-gray-200 disabled:opacity-60"
                      }`}
                    title={isDeleting ? "Deleting…" : "Delete screen"}
                  >
                    {isDeleting ? (
                      <GradientLoader size={14} />
                    ) : (
                      <Trash2 style={{ width: "1em", height: "1em" }} />
                    )}
                  </button>
                )}
              </div>
              <div
                className={`flex text-sm items-start gap-2 font-medium w-full transition-colors duration-300 text-wrap truncate ${selectedScreen?.id === screen.id
                    ? "text-white"
                    : "text-gray-700"
                  }`}
              >
                {((str) => {
                  const words = str
                    .replace(/_/g, " ")
                    .replace(/([a-z])([A-Z])/g, "$1 $2")
                    .split(" ");
                  return words
                    .map((word, i) =>
                      i === 0
                        ? word.charAt(0).toUpperCase() +
                        word.slice(1).toLowerCase()
                        : word.toLowerCase(),
                    )
                    .join(" ");
                })(screen.screenContents?.contentType || "Content")}{" "}
              </div>
              <div
                className={`flex flex-col items-start bg-white p-2 mt-0.5 shrink-0 transition-all duration-300  shadow-sm overflow-hidden${selectedScreen?.id === screen.id
                    ? " h-52.5 w-36.25"
                    : " h-42.5 w-33.75" // normal screen size
                  }`}
              >
                {/* Title */}
                <div
                  className={`flex items-start gap-2 text-sm font-medium w-full transition-colors duration-300 mb-1 text-wrap ${selectedScreen?.id === screen.id
                      ? "text-black"
                      : "text-black"
                    }`}
                  title={screen.screenContents?.name || screen.title}
                >
                  {screen.screenContents?.name || screen.title}
                </div>

                {/* Thumbnail */}
                {showImagePreview && (
                  <div
                    className={`relative w-full mb-2 ${selectedScreen?.id === screen.id ? "h-25" : "h-22.5"
                      }`}
                  >
                    <img
                      src={previewImageUrl || "/noImage.png"}
                      alt={screen.title || "Screen preview"}
                      className="w-full h-full object-cover transition-all duration-300"
                      onError={(e) => (e.target.src = "/error-img.png")}
                    />
                    {isGeneratingImages && !hasExistingThumbnail && (
                      <div className="absolute inset-0 flex items-center justify-center bg-white/60 rounded">
                        <GradientLoader size={32} />
                      </div>
                    )}
                  </div>
                )}

                {/* Key Learning Heading */}
                {/* <div
                  className={`text-sm font-medium w-full mb-1 transition-colors duration-300 ${selectedScreen?.id === screen.id
                    ? "text-black"
                    : "text-gray-700"
                    }`}
                >
                  Key Learning
                </div> */}

                <div
                  className={`w-full text-xs font-medium overflow-hidden text-ellipsis line-clamp-3 transition-colors duration-300 ${!showImagePreview ? "mt-auto" : ""
                    } ${selectedScreen?.id === screen.id
                      ? "text-black"
                      : "text-gray-700"
                    }`}
                >
                  {stripHtmlToPlainText(getScreenCardContentSnippet(screen))}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className=" w-full flex justify-between items-center">
          <Expand
            style={{ width: "1em", height: "1em" }}
            onClick={(e) => {
              e.stopPropagation();
              setIsDialogOpen(true);
            }}
            className={`cursor-pointer hover:scale-110 transition-all duration-300 ${selectedScreen?.id === screen.id ? "text-white" : "text-gray-500"
              }`}
          />
          <div
            className={`p-1 rounded transition-colors duration-300 ${selectedScreen?.id === screen.id
                ? "bg-primary-800"
                : "bg-background"
              }`}
          >
            <GripVertical
              style={{ width: "1em", height: "1em" }}
              className={`cursor-grab active:cursor-grabbing transition-colors duration-300 ${selectedScreen?.id === screen.id
                  ? "text-white"
                  : "text-gray-500"
                }`}
            />
          </div>
        </div>
      </div>

      {/* Add button that appears between cards */}

      {showAddButton && <AddButton position="left" insertIndex={index} />}
      {showAddButton && <AddButton position="right" insertIndex={index + 1} />}

      {/* Full Screen Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">
              Screen {index + 1}
            </DialogTitle>
            <DialogDescription className="sr-only">Screen details</DialogDescription>
          </DialogHeader>

          <div className="space-y-6 mt-4">
            {/* Heading */}
            {(screen.screenContents?.content?.heading ||
              screen.formData?.heading) && (
                <div>
                  <h3 className="text-2xl font-semibold mb-3 text-gray-900">
                    {screen.screenContents?.content?.heading ||
                      screen.formData?.heading}
                  </h3>
                </div>
              )}

            {/* Body (rich text: bold, italic, etc.) */}
            {(screen.screenContents?.content?.body ||
              screen.formData?.body) && (
                <div className="text-base text-gray-700 leading-relaxed">
                  {stripHtmlToPlainText(
                    screen.screenContents?.content?.body || screen.formData?.body,
                  )}
                </div>
              )}

            {/* Assets */}
            {screen.assets && screen.assets.length > 0 && (
              <div className="border-t pt-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {screen.assets.map((asset, assetIndex) => (
                    <div
                      key={assetIndex}
                      className="rounded-lg overflow-hidden border shadow-sm"
                    >
                      {asset.type === "image" && asset.url ? (
                        <img
                          src={asset.url}
                          alt={`Media ${assetIndex + 1}`}
                          className="w-full h-48 object-cover"
                          onError={(e) => {
                            e.target.src = "/error-img.png";
                          }}
                        />
                      ) : (
                        <div className="w-full h-48 bg-gray-100 flex items-center justify-center">
                          <p className="text-sm text-gray-500 capitalize">
                            {asset.type || "Asset"}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Ease Categories */}
            {screen.easeCategories && screen.easeCategories.length > 0 && (
              <div className="border-t pt-4">
                <div className="flex flex-wrap gap-2">
                  {screen.easeCategories.map((category, catIndex) => (
                    <span
                      key={catIndex}
                      className="px-3 py-1 bg-primary-100 text-primary-800 rounded-full text-sm font-medium"
                    >
                      {category}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* AssetPicker was opened from "Browse Images" in the removed dropdown.
      <AssetPicker
        sessionId={sessionId}
        screenUid={screen.uuid || screen.uid}
        isOpen={isAssetPickerOpen}
        onClose={() => setIsAssetPickerOpen(false)}
        onAssetLinked={(asset) => {
          onAssetLinked?.(screen.id, asset);
        }}
      />
      */}
    </div>
  );
}
