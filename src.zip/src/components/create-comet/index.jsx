"use client";

import React, { useState, useEffect, useCallback, useRef } from "react";
import { useForm } from "react-hook-form";
import SectionHeader from "@/components/section-header";
import FormCard from "./FormCard";
import SourceMaterialCard from "./SourceMaterialCard";
import CreateCometFooter from "./CreateCometFooter";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/Label";
import { Textarea } from "@/components/ui/Textarea";
import { CardContent } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import MultipleChoiceField from "./MultipleChoiceField";
import SliderField from "./SliderField";
import AskKyperPopup from "./AskKyperPopup";
import { graphqlClient } from "@/lib/graphql-client";
import { Info, Trash2, Link2, X } from "lucide-react";
import { toast } from "@/components/ui/toast";
import { useSessionSubscription } from "@/hooks/useSessionSubscription";
import {
  deriveTitleFromUrl,
  extractLinkTitleFromRecord,
  getFetchedTitleFromLocalStorage,
} from "@/lib/linkTitleFromUrl";

function normalizeWebpageUrlEntry(item, defaultUploaded = false) {
  if (typeof item === "string") {
    const u = item.trim();
    return {
      url: u,
      title: deriveTitleFromUrl(u),
      comment: "",
      isUploaded: defaultUploaded,
    };
  }

  const url = String(item?.webpage_url ?? item?.url ?? "").trim();
  const fromApi = (extractLinkTitleFromRecord(item) || "").trim();

  return {
    url,
    title: fromApi || getFetchedTitleFromLocalStorage(url) || deriveTitleFromUrl(url),
    comment: item?.comment ?? "",
    isUploaded:
      typeof item?.isUploaded === "boolean" ? item.isUploaded : defaultUploaded,
  };
}

function getUniqueWebpageUrlEntries(items = [], defaultUploaded = false) {
  const uniqueEntries = [];
  const seenUrls = new Map();

  items.forEach((item) => {
    const normalized = normalizeWebpageUrlEntry(item, defaultUploaded);
    const trimmedUrl = normalized.url.trim();

    if (!trimmedUrl) {
      return;
    }

    const key = trimmedUrl.toLowerCase();
    const existingIndex = seenUrls.get(key);

    if (existingIndex === undefined) {
      seenUrls.set(key, uniqueEntries.length);
      uniqueEntries.push({ ...normalized, url: trimmedUrl });
      return;
    }

    const existing = uniqueEntries[existingIndex];
    uniqueEntries[existingIndex] = {
      ...existing,
      title: existing.title || normalized.title,
      comment: existing.comment || normalized.comment,
      isUploaded: existing.isUploaded || normalized.isUploaded,
    };
  });

  return uniqueEntries;
}

export default function CreateComet({
  initialData = null,
  suggestion,
  initialInput,
  isNewComet = false,
  cometData,
  sessionData = null,
  prefillData = null,
  onSubmit,
  isLoading = false,
  error = null,
  allMessages = [],
  setAllMessages = () => {},
  onProgressChange = () => {},
  isAskingKyper = false,
  setIsAskingKyper = () => {},
}) {
  const [files, setFiles] = useState([]);
  const [webpageUrls, setWebpageUrls] = useState([]);
  const [focusedField, setFocusedField] = useState(null);
  const [blurTimeout, setBlurTimeout] = useState(null);
  const [fieldPosition, setFieldPosition] = useState(null);
  const [habitEnabled, setHabitEnabled] = useState(false);
  const [personalizationEnabled, setPersonalizationEnabled] = useState(false);
  const [chapterSkipEnabled, setChapterSkipEnabled] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const isAskingKyperRef = useRef(false);
  const autoSaveTimerRef = useRef(null);
  const isSavingRef = useRef(false);
  const prevFormDataRef = useRef(null);
  const currentFormDataRef = useRef(null);
  const chapterSkipSectionRef = useRef(null);
  const prevPersonalizationEnabledRef = useRef(personalizationEnabled);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedSessionId = localStorage.getItem("sessionId");
      if (storedSessionId) {
        setSessionId(storedSessionId);
        console.log("Auto-save: Loaded sessionId from localStorage:", storedSessionId);
      } else {
        console.log("Auto-save: No sessionId in localStorage yet");
      }
    }
  }, []);

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    watch,
    getValues,
    getFieldState,
    formState: { errors, isValid, isSubmitting },
  } = useForm({
    mode: "onChange",
    reValidateMode: "onChange",
    defaultValues: {
      cometTitle: "",
      description: "",
      clientOrg: "",
      clientWebsite: "",
      targetAudience: "",
      learningObjectives: [""],
      cometFocus: "",
      sourceMaterialFidelity: "",
      engagementFrequency: "",
      lengthFrequency: "",
      experienceType: "",
      specialInstructions: "",
      habit: "",
      personalization: "",
    },
  });

  // console.log("prefillData", prefillData);

  useEffect(() => {
    return () => {
      if (blurTimeout) {
        clearTimeout(blurTimeout);
      }
    };
  }, [blurTimeout]);

  // Note: WebSocket cleanup is now handled by SubscriptionManager

  // Track isAskingKyper in ref for subscription callback
  useEffect(() => {
    isAskingKyperRef.current = isAskingKyper;
  }, [isAskingKyper]);

  // Subscribe to session updates - temporary subscription that reuses existing subscription
  // Note: The form is updated via prefillData prop from DashboardLayout, not directly here
  // This subscription is mainly for when asking Kyper to get immediate updates
  useSessionSubscription(
    sessionId,
    (sessionData) => {
      // Only handle updates when actively asking Kyper (for immediate form updates)
      // Otherwise, updates come through prefillData prop which triggers the useEffect below
      if (!isAskingKyperRef.current) {
        return;
      }

      // Update entire form with cycle_creation_data when asking Kyper
      if (sessionData.cycle_creation_data) {
        // console.log(
        //   "Updating entire form with cycle_creation_data:",
        //   sessionData.cycle_creation_data
        // );

        const basicInfo = sessionData.cycle_creation_data["Basic Information"];
        const audienceObjectives =
          sessionData.cycle_creation_data["Audience & Objectives"];
        const experienceDesign =
          sessionData.cycle_creation_data["Experience Design"];

        setAllMessages((prev) => {
          const filteredPrev = prev.filter((msg, index) => {
            if (msg.from === "bot" && index === prev.length - 1) {
              return false;
            }
            return true;
          });
          return [
            ...filteredPrev,
            {
              from: "bot",
              content:
                basicInfo["Cycle Title"] || basicInfo["Client Organization"],
            },
          ];
        });

        if (basicInfo) {
          if (basicInfo["Cycle Title"])
            setValue("cometTitle", basicInfo["Cycle Title"]);
          if (basicInfo["Description"])
            setValue("description", basicInfo["Description"]);
          if (basicInfo["Client Organization"])
            setValue("clientOrg", basicInfo["Client Organization"]);
          if (basicInfo["Client Website"])
            setValue("clientWebsite", basicInfo["Client Website"]);
        }

        if (audienceObjectives) {
          if (audienceObjectives["Target Audience"])
            setValue("targetAudience", audienceObjectives["Target Audience"]);
          // Handle both "Learning Objectives" and "Learning and Behaviour Objectives"
          const learningObjectives =
            audienceObjectives["Learning and Behaviour Objectives"] ||
            audienceObjectives["Learning Objectives"];
          if (learningObjectives) {
            const objectivesArray = Array.isArray(learningObjectives)
              ? learningObjectives
              : typeof learningObjectives === "string"
                ? learningObjectives.split("\n").filter((obj) => obj.trim())
                : [learningObjectives];
            setValue("learningObjectives", objectivesArray);
          }
        }

        if (experienceDesign) {
          if (experienceDesign["Focus"]) {
            const focusValue = experienceDesign["Focus"];
            const lowerFocus = focusValue.toLowerCase();
            if (lowerFocus.includes("teaching new things")) {
              setValue("cometFocus", "Teaching new things");
            } else if (lowerFocus.includes("reinforcing")) {
              setValue("cometFocus", "reinforcing_applying");
            } else {
              setValue("cometFocus", focusValue);
            }
          }

          if (experienceDesign["Duration"]) {
            setValue("lengthFrequency", experienceDesign["Duration"]);
          } else if (experienceDesign["Length & Frequency"]) {
            setValue("lengthFrequency", experienceDesign["Length & Frequency"]);
          }

          if (experienceDesign["Engagement Frequency"]) {
            const engagementValue = experienceDesign["Engagement Frequency"];
            if (engagementValue.toLowerCase().includes("weekly")) {
              setValue("engagementFrequency", "weekly");
            } else if (engagementValue.toLowerCase().includes("daily")) {
              setValue("engagementFrequency", "daily");
            } else {
              setValue("engagementFrequency", engagementValue);
            }
          }

          if (experienceDesign["Source Alignment"]) {
            const sourceValue = experienceDesign["Source Alignment"];
            if (sourceValue.toLowerCase().includes("fidelity")) {
              setValue("sourceMaterialFidelity", "fidelity");
            } else if (sourceValue.toLowerCase().includes("balanced")) {
              setValue("sourceMaterialFidelity", "balanced");
            } else if (sourceValue.toLowerCase().includes("extension")) {
              setValue("sourceMaterialFidelity", "extension");
            } else {
              setValue("sourceMaterialFidelity", sourceValue);
            }
          }

          if (experienceDesign["Experience Type"])
            setValue("experienceType", experienceDesign["Experience Type"]);
          if (experienceDesign["Special Instructions"])
            setValue(
              "specialInstructions",
              experienceDesign["Special Instructions"],
            );
        }

        setIsAskingKyper(false);
      }
    },
    (error) => {
      console.error("Subscription error:", error);
      if (isAskingKyperRef.current) {
        setIsAskingKyper(false);
      }
    },
    { forceTemporary: true },
  );

  useEffect(() => {
    if (!prefillData) return;

    // Session updates pass a new `prefillData` reference on every WebSocket tick
    // (see DashboardLayout). Blind setValue() would reset caret/scroll in text fields.
    const prefillField = (name, value) => {
      if (value === undefined || value === null || value === "") return;
      if (getFieldState(name).isDirty) return;
      const current = getValues(name);
      const same =
        typeof value === "object" && value !== null
          ? JSON.stringify(current ?? null) === JSON.stringify(value)
          : current === value;
      if (same) return;
      setValue(name, value);
    };

    // console.log("CreateComet: Prefilling form with data:", prefillData);

    // Restore Habit/Path personalization toggles from enabled_attributes (persists when returning from comet-manager/outline)
    const enabledAttrs = prefillData.response_path?.enabled_attributes;
    if (enabledAttrs) {
      if (enabledAttrs.habit_enabled !== undefined) {
        setHabitEnabled(!!enabledAttrs.habit_enabled);
      }
      if (enabledAttrs.path_personalization !== undefined) {
        setPersonalizationEnabled(!!enabledAttrs.path_personalization);
      }
      if (enabledAttrs.path_personalization) {
        if (enabledAttrs.chapter_skip !== undefined) {
          setChapterSkipEnabled(!!enabledAttrs.chapter_skip);
        }
      } else {
        setChapterSkipEnabled(false);
      }
      if (enabledAttrs.habit_description) {
        prefillField("habit", enabledAttrs.habit_description);
      }
    }

    // Restore webpage URLs (with comments) from local/session so they show in the UI
    if (
      prefillData.webpage_url &&
      Array.isArray(prefillData.webpage_url) &&
      prefillData.webpage_url.length > 0
    ) {
      const normalized = getUniqueWebpageUrlEntries(
        prefillData.webpage_url,
        true,
      );
      setWebpageUrls(normalized);
    }

    if (prefillData.cycle_creation_data) {
      const basicInfo = prefillData.cycle_creation_data["Basic Information"];
      const audienceObjectives =
        prefillData.cycle_creation_data["Audience & Objectives"];
      const experienceDesign =
        prefillData.cycle_creation_data["Experience Design"];

      if (basicInfo) {
        if (basicInfo["Cycle Title"])
          prefillField("cometTitle", basicInfo["Cycle Title"]);
        if (basicInfo["Description"])
          prefillField("description", basicInfo["Description"]);
        if (basicInfo["Client Organization"])
          prefillField("clientOrg", basicInfo["Client Organization"]);
        if (basicInfo["Client Website"])
          prefillField("clientWebsite", basicInfo["Client Website"]);
      }

      if (audienceObjectives) {
        if (audienceObjectives["Target Audience"])
          prefillField("targetAudience", audienceObjectives["Target Audience"]);
        // Handle both "Learning Objectives" and "Learning and Behaviour Objectives"
        const learningObjectives =
          audienceObjectives["Learning and Behaviour Objectives"] ||
          audienceObjectives["Learning Objectives"];
        if (learningObjectives) {
          prefillField("learningObjectives", learningObjectives);
        }
      }

      if (experienceDesign) {
        // console.log("Experience Design data:", experienceDesign);
        // Map Focus field to cometFocus
        if (experienceDesign["Focus"]) {
          // Map text values to form values
          const focusValue = experienceDesign["Focus"];
          const lowerFocus = focusValue.toLowerCase();
          if (
            lowerFocus.includes("teaching new things") ||
            lowerFocus.includes("teaching new")
          ) {
            prefillField("cometFocus", "Teaching new things");
          } else if (
            lowerFocus.includes("reinforcing") ||
            lowerFocus.includes("applying")
          ) {
            prefillField("cometFocus", "reinforcing_applying");
          } else {
            prefillField("cometFocus", focusValue);
          }
        }

        // Map Duration field to lengthFrequency
        if (experienceDesign["Duration"]) {
          prefillField("lengthFrequency", experienceDesign["Duration"]);
        } else if (experienceDesign["Length & Frequency"]) {
          prefillField(
            "lengthFrequency",
            experienceDesign["Length & Frequency"],
          );
        }

        // Map Engagement Frequency field
        if (experienceDesign["Engagement Frequency"]) {
          const engagementValue = experienceDesign["Engagement Frequency"];
          if (engagementValue.toLowerCase().includes("weekly")) {
            prefillField("engagementFrequency", "weekly");
          } else if (engagementValue.toLowerCase().includes("daily")) {
            prefillField("engagementFrequency", "daily");
          } else {
            prefillField("engagementFrequency", engagementValue);
          }
        }

        if (experienceDesign["Source Alignment"]) {
          const sourceValue = experienceDesign["Source Alignment"];
          if (sourceValue.toLowerCase().includes("fidelity")) {
            prefillField("sourceMaterialFidelity", "fidelity");
          } else if (sourceValue.toLowerCase().includes("balanced")) {
            prefillField("sourceMaterialFidelity", "balanced");
          } else if (sourceValue.toLowerCase().includes("extension")) {
            prefillField("sourceMaterialFidelity", "extension");
          } else {
            prefillField("sourceMaterialFidelity", sourceValue);
          }
        }

        if (experienceDesign["Experience Type"])
          prefillField("experienceType", experienceDesign["Experience Type"]);
        if (experienceDesign["Special Instructions"])
          prefillField(
            "specialInstructions",
            experienceDesign["Special Instructions"],
          );
      }

      if (prefillData.cycle_creation_data["Source Materials"]) {
      }
    } else {
      if (prefillData.cometTitle)
        prefillField("cometTitle", prefillData.cometTitle);
      if (prefillData.description)
        prefillField("specialInstructions", prefillData.description);
      if (prefillData.specialInstructions)
        prefillField("specialInstructions", prefillData.specialInstructions);
      if (prefillData.targetAudience)
        prefillField("targetAudience", prefillData.targetAudience);
      if (prefillData.learningObjectives) {
        const objectives = Array.isArray(prefillData.learningObjectives)
          ? prefillData.learningObjectives
          : typeof prefillData.learningObjectives === "string"
            ? prefillData.learningObjectives
                .split("\n")
                .filter((obj) => obj.trim())
            : [prefillData.learningObjectives];
        prefillField("learningObjectives", objectives);
      }
      if (prefillData.cometFocus)
        prefillField("cometFocus", prefillData.cometFocus);
      if (prefillData.sourceMaterialFidelity)
        prefillField(
          "sourceMaterialFidelity",
          prefillData.sourceMaterialFidelity,
        );
      if (prefillData.engagementFrequency)
        prefillField("engagementFrequency", prefillData.engagementFrequency);
      if (prefillData.lengthFrequency)
        prefillField("lengthFrequency", prefillData.duration);
      if (prefillData.clientOrg) prefillField("clientOrg", prefillData.clientOrg);
      if (prefillData.clientWebsite)
        prefillField("clientWebsite", prefillData.clientWebsite);
    }
  }, [prefillData, setValue, getValues, getFieldState]);

  useEffect(() => {
    const wasPersonalizationEnabled = prevPersonalizationEnabledRef.current;

    if (personalizationEnabled && !wasPersonalizationEnabled) {
      setChapterSkipEnabled(true);
      if (typeof window !== "undefined") {
        window.requestAnimationFrame(() => {
          chapterSkipSectionRef.current?.scrollIntoView({
            behavior: "smooth",
            block: "center",
          });
        });
      }
      return;
    }

    if (!personalizationEnabled) {
      setChapterSkipEnabled(false);
    }

    prevPersonalizationEnabledRef.current = personalizationEnabled;
  }, [personalizationEnabled]);

  // Track form changes in real-time using subscription (including toggle states)
  useEffect(() => {
    console.log("Auto-save: Setting up form subscription");
    const subscription = watch((values) => {
      // Include toggle states in the form data for tracking
      const formDataWithToggles = {
        ...values,
        habitEnabled,
        personalizationEnabled,
        chapterSkipEnabled,
      };
      const formDataString = JSON.stringify(formDataWithToggles);
      const prevString = currentFormDataRef.current;
      currentFormDataRef.current = formDataString;

      // Debug: log when form values change (only for cometTitle and description to avoid spam)
      if (values.cometTitle || values.description) {
        const changed = prevString !== formDataString;
        console.log("Form values updated:", {
          cometTitle: values.cometTitle,
          description: values.description,
          habitEnabled,
          personalizationEnabled,
          chapterSkipEnabled,
          changed: changed,
          hasPrevData: !!prevString
        });
      }
    });
    return () => {
      console.log("Auto-save: Cleaning up form subscription");
      subscription.unsubscribe();
    };
  }, [watch, habitEnabled, personalizationEnabled, chapterSkipEnabled]);

  // Initialize prevFormDataRef after form is populated from prefillData
  useEffect(() => {
    if (prefillData && prevFormDataRef.current === null) {
      // Use setTimeout to ensure form values are set before initializing
      const timer = setTimeout(() => {
        const currentFormValues = watch();
        const formDataWithToggles = {
          ...currentFormValues,
          habitEnabled,
          personalizationEnabled,
          chapterSkipEnabled,
        };
        const formDataString = JSON.stringify(formDataWithToggles);
        prevFormDataRef.current = formDataString;
        currentFormDataRef.current = formDataString;
      }, 200);
      return () => clearTimeout(timer);
    }
  }, [prefillData, watch, habitEnabled, personalizationEnabled, chapterSkipEnabled]);

  // Update tracked data when toggles change - this triggers auto-save detection
  useEffect(() => {
    // Only update if we have previous data (form is initialized)
    if (prevFormDataRef.current === null) {
      return;
    }

    const currentFormValues = watch();
    const formDataWithToggles = {
      ...currentFormValues,
      habitEnabled,
      personalizationEnabled,
      chapterSkipEnabled,
    };
    const formDataString = JSON.stringify(formDataWithToggles);
    const prevString = currentFormDataRef.current;

    // Update current ref with new toggle states
    currentFormDataRef.current = formDataString;

    // Check if this is a real change (not just initialization)
    const hasChanged = prevString && prevString !== formDataString;

    console.log("Auto-save: Toggle states changed:", {
      habitEnabled,
      personalizationEnabled,
      chapterSkipEnabled,
      hasChanged,
      willTriggerAutoSave: hasChanged
    });

    // If this is a change (not initialization), the next interval tick will detect it
  }, [habitEnabled, personalizationEnabled, chapterSkipEnabled, watch]);

  const requiredFields = [
    "cometTitle",
    "clientOrg",
    "targetAudience",
    "learningObjectives",
    "cometFocus",
    "sourceMaterialFidelity",
    "engagementFrequency",
    "lengthFrequency",
    "specialInstructions",
  ];

  const [isUploadingSources, setIsUploadingSources] = useState(false);

  const handleFormSubmit = async (data) => {
    try {
      if (onSubmit) {
        const uniqueWebpageUrls = getUniqueWebpageUrlEntries(webpageUrls);
        // Include toggle states and their associated data
        const formData = {
          ...data,
          habitEnabled,
          habitText: data.habit || "",
          personalizationEnabled,
          chapterSkipEnabled:
            personalizationEnabled && chapterSkipEnabled,
          sourceFiles: files,
          webpage_url: uniqueWebpageUrls
            .map((e) => ({
              webpage_url: e.url.trim(),
              title: e.title ?? "",
              comment: e.comment ?? "",
            })),
        };
        await onSubmit(formData);
      }
    } catch (error) {
      console.error("Error saving comet data:", error);
    }
  };
  //progress bar logic
  useEffect(() => {
    const calculateProgress = (values) => {
      if (!requiredFields.length) return 0;
      const filledCount = requiredFields.filter((field) => {
        const value = values[field];
        if (typeof value === "string") {
          return value.trim().length > 0;
        }
        if (Array.isArray(value)) {
          return value.some((item) => item && item.trim().length > 0);
        }
        return Boolean(value);
      }).length;
      return Math.round((filledCount / requiredFields.length) * 100);
    };

    const initialValues = watch();
    onProgressChange(calculateProgress(initialValues));

    const subscription = watch((values) => {
      onProgressChange(calculateProgress(values));
    });

    return () => subscription.unsubscribe();
  }, [watch, onProgressChange]);

  // Auto-save functionality - similar to CometManagerLayout
  useEffect(() => {
    if (autoSaveTimerRef.current) {
      clearInterval(autoSaveTimerRef.current);
    }

    // Get sessionId from props or localStorage
    const currentSessionId = sessionId || (typeof window !== "undefined" ? localStorage.getItem("sessionId") : null);

    if (!currentSessionId) {
      console.log("Auto-save: No sessionId available, skipping auto-save setup");
      return;
    }

    console.log("Auto-save: Setting up auto-save with sessionId:", currentSessionId);

    // Initialize on first run if not already initialized
    if (prevFormDataRef.current === null && currentFormDataRef.current === null) {
      const initialValues = watch();
      const initialDataWithToggles = {
        ...initialValues,
        habitEnabled,
        personalizationEnabled,
        chapterSkipEnabled,
      };
      const initialDataString = JSON.stringify(initialDataWithToggles);
      prevFormDataRef.current = initialDataString;
      currentFormDataRef.current = initialDataString;
    }

    // Auto-save functionality - check every 5 seconds if data changed
    console.log("Auto-save: Starting interval timer (5 seconds)");
    autoSaveTimerRef.current = setInterval(async () => {
      console.log("Auto-save: Interval tick - checking for changes...");

      if (isSavingRef.current) {
        console.log("Auto-save: Already saving, skipping...");
        return;
      }

      // Get current form data from ref (updated by subscription)
      const currentFormDataString = currentFormDataRef.current;
      const prevFormDataString = prevFormDataRef.current;

      console.log("Auto-save: Refs status:", {
        hasCurrent: !!currentFormDataString,
        hasPrev: !!prevFormDataString,
        currentLength: currentFormDataString?.length,
        prevLength: prevFormDataString?.length
      });

      // If refs are not initialized, try to get from watch
      if (!currentFormDataString || !prevFormDataString) {
        const currentFormValues = watch();
        const formDataWithToggles = {
          ...currentFormValues,
          habitEnabled,
          personalizationEnabled,
          chapterSkipEnabled,
        };
        const formDataString = JSON.stringify(formDataWithToggles);
        if (!prevFormDataRef.current) {
          prevFormDataRef.current = formDataString;
          console.log("Auto-save: Initialized prevFormDataRef");
        }
        if (!currentFormDataRef.current) {
          currentFormDataRef.current = formDataString;
          console.log("Auto-save: Initialized currentFormDataRef");
        }
        return;
      }

      const formDataChanged = currentFormDataString !== prevFormDataString;

      // Debug: log comparison with toggle states
      if (formDataChanged) {
        try {
          const current = JSON.parse(currentFormDataString);
          const prev = prevFormDataString ? JSON.parse(prevFormDataString) : null;
          console.log("Auto-save: Form data changed detected", {
            habitEnabled: {
              current: current.habitEnabled,
              prev: prev?.habitEnabled,
              stateValue: habitEnabled
            },
            personalizationEnabled: {
              current: current.personalizationEnabled,
              prev: prev?.personalizationEnabled,
              stateValue: personalizationEnabled
            },
            chapterSkipEnabled: {
              current: current.chapterSkipEnabled,
              prev: prev?.chapterSkipEnabled,
              stateValue: chapterSkipEnabled
            },
            togglesChanged: prev ? (current.habitEnabled !== prev.habitEnabled || current.personalizationEnabled !== prev.personalizationEnabled || current.chapterSkipEnabled !== prev.chapterSkipEnabled) : false
          });
        } catch (e) {
          console.log("Auto-save: Form data changed detected (parse error)");
        }
      }

      if (formDataChanged && prevFormDataString !== null && currentFormDataString) {
        console.log("Form data changed, triggering auto-save...");
        let currentFormValues;
        try {
          currentFormValues = JSON.parse(currentFormDataString);
        } catch (parseError) {
          console.error("Error parsing form data for auto-save:", parseError);
          return;
        }

        // Use current state values for toggles (they're the source of truth)
        // Override any values from parsed JSON with current state
        currentFormValues.habitEnabled = habitEnabled;
        currentFormValues.personalizationEnabled = personalizationEnabled;
        currentFormValues.chapterSkipEnabled =
          personalizationEnabled && chapterSkipEnabled;

        try {
          isSavingRef.current = true;

          const currentSessionIdForSave =
            sessionId ||
            (typeof window !== "undefined" &&
              localStorage.getItem("sessionId")) ||
            null;

          if (!currentSessionIdForSave) {
            console.warn("Auto-save: No session ID available for auto-save");
            return;
          }

          console.log("Auto-save: Starting save process for sessionId:", currentSessionIdForSave);

          // Format form data similar to handleFormSubmit
          const formattedCometData = {
            "Basic Information": {
              "Cycle Title": currentFormValues.cometTitle || "",
              Description: currentFormValues.description || "",
              "Client Organization": currentFormValues.clientOrg || "",
              "Client Website": currentFormValues.clientWebsite || "",
            },
            "Audience & Objectives": {
              "Target Audience": currentFormValues.targetAudience || "",
              "Learning and Behaviour Objectives": Array.isArray(
                currentFormValues.learningObjectives,
              )
                ? currentFormValues.learningObjectives
                    .map(String)
                    .map((obj) => obj.trim())
                    .filter(Boolean)
                : typeof currentFormValues.learningObjectives === "string"
                  ? currentFormValues.learningObjectives
                      .split(",")
                      .map((obj) => obj.trim())
                      .filter(Boolean)
                  : [],
            },
            "Experience Design": {
              Focus: currentFormValues.cometFocus || "",
              "Source Alignment": currentFormValues.sourceMaterialFidelity || "",
              "Engagement Frequency": currentFormValues.engagementFrequency || "",
              Duration: currentFormValues.lengthFrequency || "",
              "Special Instructions": currentFormValues.specialInstructions || "",
            },
          };

          // Get existing session data
          let parsedSessionData = null;
          try {
            const raw = localStorage.getItem("sessionData");
            if (raw) parsedSessionData = JSON.parse(raw);
          } catch {}

          // Initialize enabled_attributes object
          // Use current state values directly (they're the source of truth)
          // Use current state values directly - they're always up-to-date
          const currentHabitEnabled = habitEnabled;
          const currentPersonalizationEnabled = personalizationEnabled;
          const currentChapterSkipEnabled =
            personalizationEnabled && chapterSkipEnabled;

          console.log("Auto-save: Toggle states being saved:", {
            habitEnabled: currentHabitEnabled,
            personalizationEnabled: currentPersonalizationEnabled,
            chapterSkipEnabled: currentChapterSkipEnabled,
            stateValues: {
              habit: habitEnabled,
              personalization: personalizationEnabled,
              chapterSkip: chapterSkipEnabled
            },
            parsedValues: {
              habit: currentFormValues.habitEnabled,
              personalization: currentFormValues.personalizationEnabled,
              chapterSkip: currentFormValues.chapterSkipEnabled
            }
          });

          const enabled_attributes = {
            ...(parsedSessionData?.response_path?.enabled_attributes || {}),
            path_personalization: currentPersonalizationEnabled,
            chapter_skip: currentChapterSkipEnabled,
            habit_enabled: currentHabitEnabled,
            habit_description: currentFormValues.habit || "",
          };

          console.log("Auto-save: enabled_attributes being saved:", {
            path_personalization: enabled_attributes.path_personalization,
            chapter_skip: enabled_attributes.chapter_skip,
            habit_enabled: enabled_attributes.habit_enabled
          });

          // Ensure response_path exists and update with new enabled_attributes
          if (!parsedSessionData) {
            parsedSessionData = {};
          }
          if (!parsedSessionData.response_path) {
            parsedSessionData.response_path = {};
          }
          // Update enabled_attributes with new toggle values
          parsedSessionData.response_path.enabled_attributes = enabled_attributes;

          // Create response_path object with updated enabled_attributes
          const updatedResponsePath = {
            ...(parsedSessionData?.response_path || {}),
            enabled_attributes: enabled_attributes,
          };

          const cometJsonForSave = JSON.stringify({
            session_id: currentSessionIdForSave,
            input_type: "cycle_data_update",
            cycle_creation_data: formattedCometData,
            response_outline: parsedSessionData?.response_outline || {},
            response_path: updatedResponsePath, // Use updated response_path with new enabled_attributes
            chatbot_conversation: parsedSessionData?.chatbot_conversation || [],
            to_modify: parsedSessionData?.to_modify || {},
          });

          console.log("Auto-save: Calling autoSaveComet with data:", {
            session_id: currentSessionIdForSave,
            cometTitle: formattedCometData["Basic Information"]["Cycle Title"],
            description: formattedCometData["Basic Information"]["Description"],
            enabled_attributes_in_payload: updatedResponsePath.enabled_attributes
          });

          const response = await graphqlClient.autoSaveComet(cometJsonForSave);
          if (response && response.autoSaveComet) {
            try {
              let savedData;
              if (typeof response.autoSaveComet === "string") {
                const parsedResponse = JSON.parse(response.autoSaveComet);
                savedData = {
                  ...parsedSessionData,
                  ...parsedResponse,
                  cycle_creation_data: formattedCometData,
                  chatbot_conversation:
                    parsedResponse.chatbot_conversation ||
                    parsedSessionData?.chatbot_conversation ||
                    [],
                };
                // Ensure enabled_attributes are updated in saved data
                if (!savedData.response_path) {
                  savedData.response_path = {};
                }
                savedData.response_path.enabled_attributes = {
                  ...(savedData.response_path.enabled_attributes || {}),
                  ...enabled_attributes,
                };
              } else {
                savedData = {
                  ...parsedSessionData,
                  cycle_creation_data: formattedCometData,
                };
                // Ensure enabled_attributes are updated in saved data
                if (!savedData.response_path) {
                  savedData.response_path = {};
                }
                savedData.response_path.enabled_attributes = {
                  ...(savedData.response_path.enabled_attributes || {}),
                  ...enabled_attributes,
                };
              }

              localStorage.setItem("sessionData", JSON.stringify(savedData));
              prevFormDataRef.current = currentFormDataString;
              console.log("Auto-save successful", {
                enabled_attributes: savedData.response_path?.enabled_attributes
              });
            } catch (parseError) {
              console.error("Error parsing auto-save response:", parseError);
              const updatedSessionData = {
                ...parsedSessionData,
                cycle_creation_data: formattedCometData,
                chatbot_conversation: parsedSessionData?.chatbot_conversation || [],
              };
              // Ensure enabled_attributes are updated even on error
              if (!updatedSessionData.response_path) {
                updatedSessionData.response_path = {};
              }
              updatedSessionData.response_path.enabled_attributes = {
                ...(updatedSessionData.response_path.enabled_attributes || {}),
                ...enabled_attributes,
              };
              localStorage.setItem(
                "sessionData",
                JSON.stringify(updatedSessionData),
              );
              prevFormDataRef.current = currentFormDataString;
              console.log("Auto-save: Saved to localStorage with enabled_attributes:", {
                enabled_attributes: updatedSessionData.response_path.enabled_attributes
              });
            }
          }
        } catch (error) {
          console.error("Error during auto-save:", error);
        } finally {
          isSavingRef.current = false;
        }
      }
    }, 5000);

    return () => {
      if (autoSaveTimerRef.current) {
        clearInterval(autoSaveTimerRef.current);
        console.log("Auto-save: Cleaned up interval");
      }
    };
  }, [sessionId, habitEnabled, personalizationEnabled, chapterSkipEnabled, watch]);

  const handleAskKyper = async (query) => {
    try {
      setIsAskingKyper(true);

      const formValues = watch();

      let currentSessionId =
        sessionId ||
        (typeof window !== "undefined"
          ? localStorage.getItem("sessionId")
          : null);

      const formattedCometData = {
        "Basic Information": {
          "Cycle Title": formValues.cometTitle || "",
          Description: formValues.description || "",
          "Client Organization": formValues.clientOrg || "",
          "Client Website": formValues.clientWebsite || "",
        },
        "Audience & Objectives": {
          "Target Audience": formValues.targetAudience || "",
          "Learning Objectives": Array.isArray(formValues.learningObjectives)
            ? formValues.learningObjectives.filter((obj) => obj && obj.trim())
            : formValues.learningObjectives || "",
        },
        "Experience Design": {
          "Length & Frequency": formValues.D || "",
          "Experience Type": "",
          "Special Instructions": formValues.specialInstructions || "",
        },
      };

      const fieldLabelMap = {
        cometTitle: "Cycle Title",
        description: "Description",
        clientOrg: "Client Organization",
        clientWebsite: "Client Website",
      };

      const fieldLabel = fieldLabelMap[focusedField] || focusedField;
      const currentFieldValue = formValues[focusedField] || "";
      let parsedSessionData = null;
      try {
        const raw = localStorage.getItem("sessionData");
        if (raw) parsedSessionData = JSON.parse(raw);
      } catch {}
      const chatbotConversation = parsedSessionData?.chatbot_conversation || [];

      const conversationMessage = `{ 'field': '${fieldLabel}', 'value': '${currentFieldValue}', 'instruction': '${query}' }`;
      // {
      //   field: fieldLabel,
      //   value: currentFieldValue,
      //   instruction: query,
      // };

      console.log("conversationMessage object:", conversationMessage);
      setAllMessages((prev) => [
        ...prev,
        { from: "user", content: query || "" },
      ]);

      const additionalData = {
        personalization_enabled: personalizationEnabled || false,
        chapter_skip: (personalizationEnabled && chapterSkipEnabled) || false,
        habit_enabled: habitEnabled || false,
        habit_description: formValues.habit || "",
      };
      const uniqueWebpageUrls = getUniqueWebpageUrlEntries(webpageUrls);

      const cometJsonForMessage = JSON.stringify({
        session_id: currentSessionId,
        input_type: "cycle_data_update",
        cycle_creation_data: formattedCometData,
        response_outline: {},
        response_path: {},
        additional_data: additionalData,
        chatbot_conversation: [
          ...chatbotConversation,
          { user: conversationMessage },
        ],
        to_modify: {},
        webpage_url: uniqueWebpageUrls
          .map((e) => ({
            webpage_url: e.url.trim(),
            title: e.title ?? "",
            comment: e.comment ?? "",
          })),
      });

      console.log("Final payload:", cometJsonForMessage, {
        session_id: currentSessionId,
        input_type: "cycle_data_update",
        cycle_creation_data: formattedCometData,
        response_outline: {},
        response_path: {},
        additional_data: additionalData,
        chatbot_conversation: [
          ...chatbotConversation,
          { user: conversationMessage },
        ],
        to_modify: {},
      });
      const messageResponse =
        await graphqlClient.sendMessage(cometJsonForMessage);
      console.log(
        "Message sent, waiting for AI response via WebSocket:",
        messageResponse,
      );

      console.log(
        "messageResponse>>>>>>>>>>>.test",
        messageResponse.sendMessage,
      );
      setAllMessages((prev) => [
        ...prev,
        // { from: "bot", content: messageResponse.sendMessage },
      ]);
      // }
    } catch (error) {
      console.error("Error asking Kyper:", error);
    }
  };

  const handleTextSelection = (fieldName, e) => {
    if (blurTimeout) {
      clearTimeout(blurTimeout);
      setBlurTimeout(null);
    }

    if (!e?.target) return;

    const input = e.target;
    const start = input.selectionStart;
    const end = input.selectionEnd;
    const hasTextSelected = start !== end && start !== null && end !== null;

    if (hasTextSelected) {
      setFocusedField(fieldName);
      const rect = input.getBoundingClientRect();
      setFieldPosition({
        top: rect.bottom + 10,
        left: rect.left,
      });
    } else {
      setFocusedField(null);
      setFieldPosition(null);
    }
  };

  const handleFieldBlur = (e) => {
    if (e?.target) {
      const input = e.target;
      const start = input.selectionStart;
      const end = input.selectionEnd;
      const hasTextSelected = start !== end && start !== null && end !== null;

      // If text is selceted, the close timeout will not statr
      if (hasTextSelected) {
        return;
      }
    }

    const timeout = setTimeout(() => {
      setFocusedField(null);
      setFieldPosition(null);
    }, 500);
    setBlurTimeout(timeout);
  };

  const handlePopupInteract = () => {
    if (blurTimeout) {
      clearTimeout(blurTimeout);
      setBlurTimeout(null);
    }
  };

  useEffect(() => {
    if (!focusedField) return;

    const shouldDismissOnKey = (event) => {
      if (
        event.ctrlKey ||
        event.metaKey ||
        event.altKey ||
        event.isComposing ||
        event.key === "Escape" ||
        event.key === "Tab" ||
        event.key.startsWith("Arrow")
      ) {
        return false;
      }

      return (
        event.key.length === 1 ||
        event.key === "Backspace" ||
        event.key === "Delete" ||
        event.key === "Enter"
      );
    };

    const handleReplaceSelection = (event) => {
      if (!shouldDismissOnKey(event)) return;

      const activeElement = document.activeElement;
      if (!activeElement) return;

      if (activeElement.closest?.("[data-ask-kyper-popup]")) {
        return;
      }

      setFocusedField(null);
      setFieldPosition(null);
    };

    document.addEventListener("keydown", handleReplaceSelection, true);
    return () => {
      document.removeEventListener("keydown", handleReplaceSelection, true);
    };
  }, [focusedField]);

  // Toggle Switch Component
  const ToggleSwitch = ({ checked, onChange, label, showInfo = false }) => (
    <div className="flex items-center justify-between py-2">
      <div className="flex items-center gap-2">
        <Label className="text-sm font-medium text-gray-800">{label}</Label>
        {showInfo && (
          <Info
            size={16}
            className="text-gray-500 cursor-help"
            title="Information about this field"
          />
        )}
      </div>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 ${
          checked ? "bg-primary" : "bg-gray-300"
        }`}
        role="switch"
        aria-checked={checked}
      >
        <span
          className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-sm transition-transform duration-200 ease-in-out ${
            checked ? "translate-x-6" : "translate-x-1"
          }`}
        />
      </button>
    </div>
  );

  const handleAddObjective = () => {
    const current = watch("learningObjectives") || [""];
    setValue("learningObjectives", [...current, ""]);
  };

  const handleDeleteObjective = (index) => {
    const current = watch("learningObjectives") || [""];
    if (current.length > 1) {
      const updated = current.filter((_, i) => i !== index);
      setValue("learningObjectives", updated);
    } else {
      // Keep at least one empty objective
      setValue("learningObjectives", [""]);
    }
  };

  return (
    <>
      <form
        onSubmit={handleSubmit(handleFormSubmit)}
        className="flex flex-col flex-1 w-full h-full bg-background rounded-xl"
      >
        <div className="w-full px-2 pt-2">
          <SectionHeader title="Create New Cycle" />
        </div>
        <div className="p-1 sm:p-2 w-full h-full overflow-y-auto create-comet-scrollbar">
          <div className="flex flex-col lg:flex-row gap-2 sm:gap-4 bg-primary-50 rounded-xl h-full p-1 sm:p-2">
            <div className="flex p-1 sm:p-2 w-full lg:w-1/2 bg-background rounded-xl">
              <div className="flex flex-1 flex-col border border-gray-200 rounded-sm h-full space-y-3 sm:space-y-4 p-2 sm:p-4 overflow-y-auto ">
                <FormCard
                  title="Basic Information"
                  className="text-semibold p-0! m-0!"
                  headerClassName="p-0 m-0"
                >
                  <CardContent className="space-y-3 pb-4">
                    <div className="space-y-1">
                      <Label htmlFor="comet-title">Cycle Title</Label>
                      <Input
                        id="comet-title"
                        placeholder="Enter Cycle Title"
                        {...register("cometTitle")}
                        onSelect={(e) => handleTextSelection("cometTitle", e)}
                        onBlur={(e) => handleFieldBlur(e)}
                        className="border border-gray-200 rounded-sm outline-none focus-visible:ring-0 focus-visible:ring-offset-0 hover:border-primary-300"
                      />
                      {errors.cometTitle && (
                        <p className="text-red-600 text-sm">
                          {errors.cometTitle.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-1">
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        rows={4}
                        placeholder="Enter description"
                        {...register("description")}
                        onSelect={(e) => handleTextSelection("description", e)}
                        onBlur={(e) => handleFieldBlur(e)}
                        className="border border-gray-200 rounded-sm outline-none focus-visible:ring-0 focus-visible:ring-offset-0 hover:border-primary-300 resize-none overflow-y-auto create-comet-scrollbar"
                      />
                      {errors.description && (
                        <p className="text-red-600 text-sm">
                          {errors.description.message}
                        </p>
                      )}
                    </div>

                    {/* <div className="space-y-1">
                      <Label htmlFor="client-website">Client Website</Label>
                      <Input
                        id="client-website"
                        placeholder="Enter client website URL"
                        {...register("clientWebsite")}
                        onFocus={(e) => handleFieldFocus("clientWebsite", e)}
                        onBlur={handleFieldBlur}
                      />
                      {errors.clientWebsite && (
                        <p className="text-red-600 text-sm">
                          {errors.clientWebsite.message}
                        </p>
                      )} 
                    </div> */}
                  </CardContent>
                </FormCard>

                <FormCard title="Audience & Objectives">
                  <CardContent className="space-y-3">
                    <div className="space-y-1">
                      <Label htmlFor="target-audience">Target Audience</Label>
                      <Textarea
                        id="target-audience"
                        rows={3}
                        placeholder="Describe your target audience"
                        {...register("targetAudience")}
                        onSelect={(e) =>
                          handleTextSelection("targetAudience", e)
                        }
                        className="border border-gray-200 rounded-sm outline-none focus-visible:ring-0 focus-visible:ring-offset-0 hover:border-primary-300"
                      />
                      {errors.targetAudience && (
                        <p className="text-red-600 text-sm">
                          {errors.targetAudience.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="learning-objectives">
                        Learning and Behavior Objectives
                      </Label>
                      <div className="space-y-2">
                        {(watch("learningObjectives") || [""]).map(
                          (objective, index) => (
                            <div key={index} className="flex gap-2 items-start">
                              <Textarea
                                id={`learning-objective-${index}`}
                                placeholder={`Learning objective ${index + 1}`}
                                value={objective || ""}
                                onChange={(e) => {
                                  const current = watch(
                                    "learningObjectives",
                                  ) || [""];
                                  const updated = [...current];
                                  updated[index] = e.target.value;
                                  setValue("learningObjectives", updated);
                                }}
                                onSelect={(e) =>
                                  handleTextSelection(
                                    `learningObjectives.${index}`,
                                    e,
                                  )
                                }
                                className="border border-gray-200 rounded-sm outline-none focus-visible:ring-0 focus-visible:ring-offset-0 hover:border-primary-300 min-h-10 flex-1"
                              />
                              <Button
                                size="sm"
                                type="button"
                                variant="ghost"
                                onClick={() => handleDeleteObjective(index)}
                                className="text-red-600 p-2 shrink-0"
                                title="Delete objective"
                              >
                                <Trash2 size={16} />
                              </Button>
                            </div>
                          ),
                        )}
                        <Button
                          size="sm"
                          type="button"
                          variant="outline"
                          onClick={handleAddObjective}
                          className="border-primary text-primary hover:bg-primary hover:text-white bg-transparent"
                        >
                          Add
                        </Button>
                      </div>
                      {errors.learningObjectives && (
                        <p className="text-red-600 text-sm">
                          {errors.learningObjectives.message}
                        </p>
                      )}
                    </div>
                  </CardContent>
                </FormCard>

                <FormCard title="Experience Design">
                  <CardContent className="space-y-4">
                    <MultipleChoiceField
                      label="What's the focus of this Cycle?"
                      name="cometFocus"
                      options={[
                        {
                          value: "Teaching new things",
                          label: "Teaching new things",
                        },
                        {
                          value: "reinforcing_applying",
                          label: "Reinforcing & applying",
                        },
                      ]}
                      required={false}
                      value={watch("cometFocus")}
                      onChange={(e) => {
                        setValue("cometFocus", e.target.value);
                      }}
                      orientation="horizontal"
                    />

                    <SliderField
                      label="How closely should this Cycle follow your source materials?"
                      name="sourceMaterialFidelity"
                      options={[
                        { value: "fidelity", label: "Fidelity" },
                        { value: "balanced", label: "Balanced" },
                        { value: "extension", label: "Extension" },
                      ]}
                      required={false}
                      value={watch("sourceMaterialFidelity")}
                      onChange={(e) => {
                        setValue("sourceMaterialFidelity", e.target.value);
                      }}
                    />

                    <MultipleChoiceField
                      label="How often should learners engage?"
                      name="engagementFrequency"
                      options={[
                        { value: "daily", label: "Daily" },
                        { value: "weekly", label: "Weekly" },
                      ]}
                      required={false}
                      value={watch("engagementFrequency")}
                      onChange={(e) => {
                        setValue("engagementFrequency", e.target.value);
                      }}
                      orientation="horizontal"
                    />

                    <div className="space-y-1">
                      <Label htmlFor="length-frequency">
                        How long should this Cycle be?
                      </Label>
                      <Input
                        id="length-frequency"
                        placeholder=" "
                        {...register("lengthFrequency")}
                        className="border border-gray-200 rounded-sm outline-none focus-visible:ring-0 focus-visible:ring-offset-0 hover:border-primary-300"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="special-instructions">
                        Special Instructions
                      </Label>
                      <Textarea
                        id="special-instructions"
                        rows={6}
                        // placeholder="Focus on practical scenarios for first-time managers. Include at least one interactive quiz and one downloadable tool template"
                        {...register("specialInstructions")}
                        onSelect={(e) =>
                          handleTextSelection("specialInstructions", e)
                        }
                        className="border border-gray-200 rounded-sm outline-none focus-visible:ring-0 focus-visible:ring-offset-0 hover:border-primary-300 resize-y min-h-[9rem] max-h-[50vh] overflow-y-auto leading-6 break-words"
                      />
                    </div>

                    {/* Separator */}
                    <div className="border-t border-gray-300 my-4"></div>

                    {/* Habit Section */}
                    <div className="space-y-3">
                      <ToggleSwitch
                        checked={habitEnabled}
                        onChange={setHabitEnabled}
                        label="Habit"
                        showInfo={true}
                      />

                      {/* <div className="relative bg-gray-100 p-1 rounded-lg">
                        <Textarea
                          id="habit"
                          rows={4}
                          placeholder="Enter habit details..."
                          {...register("habit")}
                          onSelect={(e) => handleTextSelection("habit", e)}
                          className="border border-gray-200 rounded-lg outline-none focus-visible:ring-0 focus-visible:ring-offset-0 hover:border-primary-300 resize-none"
                        />
                      </div> */}
                    </div>

                    {/* Separator */}
                    <div className="border-t border-gray-300 my-4"></div>

                    {/* Personalization Section */}
                    <div className="space-y-3">
                      <ToggleSwitch
                        checked={personalizationEnabled}
                        onChange={setPersonalizationEnabled}
                        label="Personalization"
                        showInfo={false}
                      />
                      {personalizationEnabled ? (
                        <div ref={chapterSkipSectionRef}>
                          <ToggleSwitch
                            checked={chapterSkipEnabled}
                            onChange={setChapterSkipEnabled}
                            label="Allow Users to Skip Content"
                            showInfo={false}
                          />
                        </div>
                      ) : null}
                    </div>
                  </CardContent>
                </FormCard>
              </div>
            </div>

            <div className="flex p-1 sm:p-2 w-full lg:w-1/2 bg-background rounded-xl">
              <div className="flex-1 w-full border rounded-xl overflow-auto h-full create-comet-scrollbar p-2 sm:p-4">
                <SourceMaterialCard
                  files={files}
                  setFiles={setFiles}
                  isNewComet={isNewComet}
                  webpageUrls={webpageUrls}
                  setWebpageUrls={setWebpageUrls}
                  onUploadingChange={setIsUploadingSources}
                />
              </div>
            </div>
          </div>
        </div>

        <CreateCometFooter
          reset={reset}
          handleSubmit={handleSubmit(handleFormSubmit)}
          isFormValid={isValid && !isSubmitting && !isUploadingSources}
          hasChanges={false}
          dirtyCount={0}
          isUpdating={isLoading || isSubmitting || isUploadingSources}
          error={error}
        />
      </form>

      <AskKyperPopup
        focusedField={focusedField}
        fieldPosition={fieldPosition}
        isLoading={isAskingKyper}
        onClose={() => {
          if (blurTimeout) {
            clearTimeout(blurTimeout);
            setBlurTimeout(null);
          }
          setFocusedField(null);
          setFieldPosition(null);
        }}
        onAskKyper={handleAskKyper}
        onPopupInteract={handlePopupInteract}
      />
    </>
  );
}
