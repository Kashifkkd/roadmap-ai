"use client";

import React, { useState, useEffect, useRef } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import CreateComet from "@/components/create-comet";
import ChatWindow from "@/components/chat/ChatWindow";
// import ProgressbarLoader from "@/components/loader";
import { graphqlClient } from "@/lib/graphql-client";
import Loader from "../loader3";
import { useSessionSubscription } from "@/hooks/useSessionSubscription";
import { getSourceMaterials } from "@/api/getSourceMaterials";
import { resolveSourceMaterialLinkUrl } from "@/lib/sourceMaterialLinkUrl";
import { mergeWebpageUrlTitlesFromPreviousSession } from "@/lib/mergeWebpageUrlTitles";

const normalizeUrlForKey = (url = "") =>
  (url || "").trim().toLowerCase().replace(/\/+$/, "");

const getMaterialUuid = (material) => {
  return material?.uuid || null;
};

export default function DashboardLayout() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const suggestion = searchParams.get("suggestion");
  // const initialInput = searchParams.get("initialInput");
  const userQuestionsParam = searchParams.get("userQuestions");

  // const isNewCometRef = useRef(!!initialInput);

  // State for session data
  const [sessionData, setSessionData] = useState(null);
  const [sessionId, setSessionId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isGeneratingOutline, setIsGeneratingOutline] = useState(false);
  const [error, setError] = useState(null);
  const [prefillData, setPrefillData] = useState(null);
  const [allMessages, setAllMessages] = useState([]);
  const [formProgress, setFormProgress] = useState(0);
  const [isAskingKyper, setIsAskingKyper] = useState(false);

  // Note: WebSocket cleanup is now handled by SubscriptionManager

  // Initialize sessionId and sessionData from localStorage on mount
  useEffect(() => {
    // Load sessionId
    const storedSessionId = localStorage.getItem("sessionId");
    if (storedSessionId) {
      setSessionId(storedSessionId);
    } else {
      console.log("No sessionId found in localStorage");
    }

    // Load sessionData
    const storedSessionData = localStorage.getItem("sessionData");
    if (storedSessionData) {
      try {
        const parsed = JSON.parse(storedSessionData);

        // Normalize data structure to handle different formats
        const normalized = { ...parsed };

        // Handle output.chatbot_conversation -> chatbot_conversation
        if (
          parsed.output?.chatbot_conversation &&
          !parsed.chatbot_conversation
        ) {
          normalized.chatbot_conversation = parsed.output.chatbot_conversation;
        }

        // Normalize Learning Objectives field name
        if (normalized.cycle_creation_data?.["Audience & Objectives"]) {
          const audienceObj =
            normalized.cycle_creation_data["Audience & Objectives"];
          // Handle "Learning Objectives" -> "Learning and Behaviour Objectives"
          if (
            audienceObj["Learning Objectives"] &&
            !audienceObj["Learning and Behaviour Objectives"]
          ) {
            audienceObj["Learning and Behaviour Objectives"] =
              audienceObj["Learning Objectives"];
            delete audienceObj["Learning Objectives"];
          }
        }

        setSessionData(normalized);
        setPrefillData(normalized);
      } catch (e) {
        console.error("Error parsing sessionData:", e);
      }
    } else {
      console.log(" No sessionData found in localStorage");
    }
  }, []); // Run only once on mount

  useEffect(() => {
    if (!sessionData?.chatbot_conversation) return;

    const conversation = sessionData.chatbot_conversation;
    if (!Array.isArray(conversation) || conversation.length === 0) return;

    // OLD CODE
    // const userMessage = sessionData?.chatbot_conversation?.find(
    //   (conv) => conv?.user
    // )?.user;
    // const agentMessage = sessionData?.chatbot_conversation?.find(
    //   (conv) => conv?.agent
    // )?.agent;
    //
    // if (agentMessage || userMessage) {
    //   setAllMessages((prev) => {
    //     const lastUser =
    //       prev.length > 1 ? prev[prev.length - 2]?.content : null;
    //     const lastAgent =
    //       prev.length > 0 ? prev[prev.length - 1]?.content : null;
    //     if (lastUser === userMessage && lastAgent === agentMessage) {
    //       return prev;
    //     }
    //     return [
    //       ...prev,
    //       { from: "user", content: userMessage },
    //       { from: "bot", content: agentMessage },
    //     ];
    //   });
    // }

    // NEW CODE
    const messagesToDisplay = [];

    conversation.forEach((entry) => {
      if (entry.user) {
        messagesToDisplay.push({
          from: "user",
          content: entry.user,
          status: entry.status,
          identifier: entry.identifier,
        });
      }
      if (entry.agent) {
        messagesToDisplay.push({
          from: "bot",
          content: entry.agent,
          status: entry.status,
          identifier: entry.identifier,
        });
      }
    });

    if (messagesToDisplay.length > 0) {
      setAllMessages(messagesToDisplay);
    }
  }, [sessionData]);

  // Subscribe to session updates - persistent subscription for dashboard
  useSessionSubscription(
    sessionId,
    (sessionData) => {
      let incoming = sessionData;
      try {
        const prevRaw = localStorage.getItem("sessionData");
        if (prevRaw) {
          const prev = JSON.parse(prevRaw);
          incoming = mergeWebpageUrlTitlesFromPreviousSession(sessionData, prev);
        }
      } catch (e) {
        console.warn("Dashboard: merge webpage_url titles", e);
      }

      // Normalize data structure to handle different formats
      const normalized = { ...incoming };

      // Handle output.chatbot_conversation -> chatbot_conversation
      if (
        incoming.output?.chatbot_conversation &&
        !incoming.chatbot_conversation
      ) {
        normalized.chatbot_conversation =
          incoming.output.chatbot_conversation;
      }

      // Normalize Learning Objectives field name
      if (normalized.cycle_creation_data?.["Audience & Objectives"]) {
        const audienceObj =
          normalized.cycle_creation_data["Audience & Objectives"];
        // Handle "Learning Objectives" -> "Learning and Behaviour Objectives"
        if (
          audienceObj["Learning Objectives"] &&
          !audienceObj["Learning and Behaviour Objectives"]
        ) {
          audienceObj["Learning and Behaviour Objectives"] =
            audienceObj["Learning Objectives"];
          delete audienceObj["Learning Objectives"];
        }
      }

      localStorage.setItem("sessionData", JSON.stringify(normalized));
      // Preserve enabled_attributes from current session if server didn't return them
      if (
        !normalized.response_path?.enabled_attributes &&
        incoming?.response_path?.enabled_attributes
      ) {
        normalized.response_path = {
          ...normalized.response_path,
          enabled_attributes: incoming.response_path.enabled_attributes,
        };
      }
      // Create a new object reference to ensure React detects the change
      const updatedSessionData = { ...normalized };
      setSessionData(updatedSessionData);
      // Also update prefillData so CreateComet component receives the updates
      // Using a new object reference ensures the useEffect in CreateComet triggers
      setPrefillData(updatedSessionData);

      // Navigate to outline-manager only when outline is actually generated
      // Check if response_outline has chapters data
      const hasOutline =
        normalized?.response_outline?.chapters?.length > 0 ||
        (Array.isArray(normalized?.response_outline) &&
          normalized.response_outline.length > 0);

      const hasCometData =
        normalized?.cycle_creation_data &&
        Object.keys(normalized.cycle_creation_data).length > 0;

      if (isGeneratingOutline && hasOutline) {
        router.push("/outline-manager");
      }
    },
    (error) => {
      // Enhanced error logging for debugging
      console.error("Dashboard subscription error:", {
        message: error?.message || "Unknown error",
        error: error,
        sessionId: sessionId,
        errorType: error?.constructor?.name,
      });

      // Only show user-facing errors for non-connection issues
      // WebSocket connection errors are often transient and handled by retry logic
      const isConnectionError =
        error?.message?.toLowerCase().includes("connection") ||
        error?.message?.toLowerCase().includes("websocket") ||
        error?.message?.toLowerCase().includes("network");

      if (!isConnectionError && error?.message) {
        setError(error.message);
      }
      setIsGeneratingOutline(false);
    },
  );

  // Handle form submission and navigation
  const handleFormSubmit = async (formData) => {
    try {
      setIsLoading(true);
      setError(null);

      // Check if sessionId already exists in localStorage
      let currentSessionId = sessionId || localStorage.getItem("sessionId");
      let cometJson;

      // Only create new session if one doesn't exist
      if (!currentSessionId) {
        const sessionResponse = await graphqlClient.createSession();
        currentSessionId = sessionResponse.createSession.sessionId;
        cometJson = sessionResponse.createSession.cometJson;
        localStorage.setItem("sessionId", currentSessionId);
        setSessionData(JSON.parse(cometJson));
      } else {
        console.log("Reusing existing session:", currentSessionId);
      }

      setSessionId(currentSessionId);
      if (cometJson) {
        setSessionData(JSON.parse(cometJson));
      }

      // Ensure source materials upload only after session exists.
      if (typeof window !== "undefined" && window.uploadAllFiles) {
        console.log("Uploading source materials after session is ready...");
        await window.uploadAllFiles();
        console.log("Source material upload complete");
      }

      const formattedCometData = {
        "Basic Information": {
          "Cycle Title": formData.cometTitle || "",
          Description: formData.description || "",
        },
        "Audience & Objectives": {
          "Target Audience": formData.targetAudience || "",
          "Learning and Behaviour Objectives": Array.isArray(
            formData.learningObjectives,
          )
            ? formData.learningObjectives
                .map(String)
                .map((obj) => obj.trim())
                .filter(Boolean)
            : typeof formData.learningObjectives === "string"
              ? formData.learningObjectives
                  .split(",")
                  .map((obj) => obj.trim())
                  .filter(Boolean)
              : [],
        },
        "Experience Design": {
          Focus: formData.cometFocus || "",
          "Source Alignment": formData.sourceMaterialFidelity || "",
          "Engagement Frequency": formData.engagementFrequency || "",
          Duration: formData.lengthFrequency || "",
          "Special Instructions": formData.specialInstructions || "",
        },
      };

      let parsedSessionData = null;
      try {
        const raw = localStorage.getItem("sessionData");
        if (raw) parsedSessionData = JSON.parse(raw);
      } catch {}

      const chatbotConversation = parsedSessionData?.chatbot_conversation || [];

      // Initialize enabled_attributes object
      const enabled_attributes = {
        ...(parsedSessionData?.response_path?.enabled_attributes || {}),
        path_personalization: formData.personalizationEnabled || false,
        chapter_skip:
          (formData.personalizationEnabled && formData.chapterSkipEnabled) ||
          false,
        habit_enabled: formData.habitEnabled || false,
        habit_description: formData.habitText || "",
      };

      // Ensure response_path exists before assigning enabled_attributes
      if (!parsedSessionData) {
        parsedSessionData = {};
      }
      if (!parsedSessionData.response_path) {
        parsedSessionData.response_path = {};
      }
      parsedSessionData.response_path.enabled_attributes = enabled_attributes;

      // Persist enabled_attributes to localStorage immediately so they persist
      // across dashboard → outline_manager → comet_manager
      try {
        localStorage.setItem("sessionData", JSON.stringify(parsedSessionData));
        setSessionData(parsedSessionData);
      } catch (e) {
        console.warn("Could not persist sessionData with enabled_attributes", e);
      }

      console.log(formData);

      const executionId = Math.floor(Math.random() * 10000).toString();
      // Generate UUID using crypto.getRandomValues for browser compatibility
      const traceId = globalThis.crypto.getRandomValues(new Uint8Array(16)).reduce((acc, byte) => {
        return acc + byte.toString(16).padStart(2, '0');
      }, '');
      const receivedAt = new Date().toISOString();

      // source_material payload
      let sourceMaterialsPayload = [];
      const linkUuidByUrlKey = new Map();
      try {
        const materials = await getSourceMaterials(currentSessionId);
        if (Array.isArray(materials) && materials.length > 0) {
          const localFileComments = {};
          if (Array.isArray(formData.sourceFiles)) {
            formData.sourceFiles.forEach((f) => {
              if (f.name) localFileComments[f.name] = f.comment ?? "";
            });
          }

          materials.forEach((material) => {
            if (material?.type !== "link") return;
            const linkUrl = resolveSourceMaterialLinkUrl(material);
            const urlKey = normalizeUrlForKey(linkUrl);
            const uuid = getMaterialUuid(material);
            if (urlKey && uuid) {
              linkUuidByUrlKey.set(urlKey, uuid);
            }
          });

          sourceMaterialsPayload = materials
            .map((material, idx) => {
              const index = idx + 1;
              const title =
                material.type === "link"
                  ? resolveSourceMaterialLinkUrl(material)
                  : material.source_name || "";

              if (!title) return null;

              let comment = material.comment ?? "";
              if (
                material.type !== "link" &&
                material.source_name &&
                localFileComments[material.source_name] !== undefined
              ) {
                comment = localFileComments[material.source_name];
              }

              return {
                [`source_material_${index}`]: title,
                comment,
                [`uid_${index}`]: getMaterialUuid(material),
              };
            })
            .filter(Boolean);
        }
      } catch (e) {
        console.error("Failed to fetch source materials for payload:", e);
      }

      // Clear old outline and chapters for a fresh start
      const cleanedResponsePath = {
        ...(parsedSessionData?.response_path || {}),
   chapters: [],
        remaining_chapters: [],
      };

      const cometJsonForMessage = JSON.stringify({
        session_id: currentSessionId,
        input_type: "outline_creation",
        cycle_creation_data: formattedCometData,
        response_outline: [],
        response_path: cleanedResponsePath,
        chatbot_conversation: chatbotConversation,
        to_modify: parsedSessionData?.to_modify ?? {},
        source_material: sourceMaterialsPayload,
        webpage_url: (formData.webpage_url || []).map((entry) => {
          const webpageUrl = (entry?.webpage_url ?? "").trim();
          const key = normalizeUrlForKey(webpageUrl);
          return {
            ...entry,
            webpage_url: webpageUrl,
            source_material_uid: key ? (linkUuidByUrlKey.get(key) ?? null) : null,
          };
        }),
        is_initial_chapter_created: false,
        execution_id: executionId,
        retry_count: 0,
        error_history: [],
        is_retry: false,
        metadata: JSON.stringify({
          trace_id: traceId,
          received_at: receivedAt,
          execution_id: executionId,
        }),
      });

      // Save cleaned state to Redis BEFORE triggering n8n
      // so n8n reads the clean state (no old outline/chapters)
      const cleanedSession = {
        ...parsedSessionData,
        response_outline: [],
        response_path: cleanedResponsePath,
        is_initial_chapter_created: false,
        chatbot_conversation: chatbotConversation,
      };
      localStorage.setItem("sessionData", JSON.stringify(cleanedSession));
      setSessionData(cleanedSession);

      // Flush to Redis first
      await graphqlClient.autoSaveComet(JSON.stringify({
        session_id: currentSessionId,
        input_type: "outline_creation",
        cycle_creation_data: formattedCometData,
        response_outline: [],
        response_path: cleanedResponsePath,
        chatbot_conversation: chatbotConversation,
        to_modify: parsedSessionData?.to_modify ?? {},
        webpage_url: (formData.webpage_url || []).map((entry) => {
          const webpageUrl = (entry?.webpage_url ?? "").trim();
          const key = normalizeUrlForKey(webpageUrl);
          return {
            ...entry,
            webpage_url: webpageUrl,
            source_material_uid: key ? (linkUuidByUrlKey.get(key) ?? null) : null,
          };
        }),
        is_initial_chapter_created: false,
      }));

      // Now trigger n8n — Redis has clean state
      const messageResponse =
        await graphqlClient.sendMessage(cometJsonForMessage);
      // console.log("Message response:", messageResponse);

      // Step 3: Show loading - useEffect will handle the subscription
      setIsGeneratingOutline(true);
    } catch (error) {
      console.error("Error creating session or sending message:", error);
      setError(error.message);
      setIsGeneratingOutline(false);
    } finally {
      setIsLoading(false);
    }
  };

  const handleBackFromLoading = () => {
    router.push("/configure-cycle");
    setIsGeneratingOutline(false);
  };

  if (isGeneratingOutline) {
    return (
      <div className="fixed inset-x-0 top-[64px] bottom-0 z-50 bg-primary-50">
        <div className="w-full h-full flex items-center justify-center p-2 overflow-auto">
          <Loader
            inputText="outline"
            onBack={handleBackFromLoading}
            backLabel="Back to Configure Cycle"
          />
        </div>
      </div>
    );
  }
  // const welcomeMessage = [
  //   "Review the Basic Information and Audience & Objectives sections, which I drafted based on what you've shared so far.",
  //   "Then, add Source Materials for your Comet. This means any documents that will help me draft the right learning and behavior change journey for your audience.",
  //   "Finally, configure your Comet in the Experience Design section. When you're ready, move to the next step to review your Comet Outline.",
  // ];

  return (
    <>
      <div className="flex flex-col bg-primary-50 px-2 py-2 h-full">
        <div className="h-[6px] sm:h-2 rounded-full bg-white overflow-hidden shadow-inner">
          <div
            className="h-full bg-linear-to-r from-primary-400 via-primary-500 to-primary-600 transition-[width] duration-500 ease-out shadow-[0_6px_18px_rgba(79,70,229,0.35)]"
            style={{ width: `${formProgress}%` }}
          />
        </div>
        <div className="flex flex-1 gap-2 mt-2 flex-col lg:flex-row overflow-y-auto">
          {/* Chat Window - Hidden on small screens, Desktop: 360px width */}
          <div className="lg:block w-full lg:w-[360px] h-full lg:h-full">
            <ChatWindow
              cometManager={false}
              inputType="cycle_data_update"
              pageIdentifier={1}
              initialInput={null}
              userQuestions={null}
              onResponseReceived={(updatedSessionData) => {
                setSessionData(updatedSessionData);
                setPrefillData(updatedSessionData);
              }}
              allMessages={allMessages}
              setAllMessages={setAllMessages}
              sessionData={prefillData || sessionData}
              externalLoading={isAskingKyper}
            />
          </div>

          {/* Create Comet Form - Mobile: Full width, Desktop: flex-1 */}
          <div className="w-full lg:flex-1 h-full lg:h-full">
            <CreateComet
              suggestion={suggestion}
              initialInput={null}
              isNewComet={false}
              cometData={null}
              sessionId={sessionId}
              prefillData={prefillData || sessionData}
              onSubmit={handleFormSubmit}
              isLoading={isLoading}
              error={error}
              setAllMessages={setAllMessages}
              onProgressChange={setFormProgress}
              isAskingKyper={isAskingKyper}
              setIsAskingKyper={setIsAskingKyper}
            />
          </div>
        </div>
      </div>
    </>
  );
}
