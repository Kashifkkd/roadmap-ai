"use client";

import React, { useState, useMemo, useRef, useEffect } from "react";
import ForceRankForm from "./forms/ForceRankForm";
import PollMcqForm from "./forms/PollMcqForm";
import PollLinearForm from "./forms/PollLinearForm";
import ContentForm from "./forms/ContentForm";
import HabitOptInForm from "./forms/HabitOptInForm";
import ReflectionForm from "./forms/ReflectionForm";
import ActionsForm from "./forms/ActionsForm";
import SocialDiscussionForm from "./forms/SocialDiscussionForm";
import AssessmentForm from "./forms/AssessmentForm";
import NotificationsForm from "./forms/NotificationsForm";
import MiniAppForm from "./forms/MiniAppForm";
import ProfileForm from "./forms/ProfileForm";
import EmailPromptForm from "./forms/EmailPromptForm";
import AccountabilityPartnerEmailForm from "./forms/AccountabilityPartnerEmailForm";
import PathPersonalizationForm from "./forms/PathPersonalizationForm";
import { formatContentTypeLabel } from "./formatContentTypeLabel";
import AskKyperPopup from "@/components/create-comet/AskKyperPopup";
import { graphqlClient } from "@/lib/graphql-client";

// Helper to extract plain text from Quill delta JSON
// Always converts delta format to plain text to prevent crashes
const extractPlainTextFromDelta = (value) => {
  // Handle null/undefined
  if (value == null) return "";

  // If not a string, return as-is (for numbers, booleans, etc.)
  if (typeof value !== "string") return value;

  // Empty string
  if (value.trim() === "") return value;

  // Check if it's a JSON string that might be a Quill delta
  if (value.trim().startsWith("{")) {
    try {
      const delta = JSON.parse(value);
      if (delta && delta.ops && Array.isArray(delta.ops)) {
        // Extract plain text from Quill delta ops
        const plainText = delta.ops
          .map((op) => {
            if (typeof op.insert === "string") {
              return op.insert;
            } else if (op.insert && typeof op.insert === "object") {
              // Handle embedded objects (like images, formulas, etc.)
              return "";
            }
            return "";
          })
          .join("");
        return plainText || value; // Return plain text, or original if empty
      }
    } catch (e) {
      // If parsing fails, it's not valid JSON - return as-is (plain text)
      console.log(
        "🔵 Not a valid JSON delta, treating as plain text:",
        e.message,
      );
      return value;
    }
  }

  // Not a delta format, return as plain text
  return value;
};

const stripHtmlToPlainText = (value) => {
  if (typeof value !== "string") return value;
  return value
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
};

/** Persisted habit rows: align with backend screen_schemas (id, level, …) */
const normalizeHabitRowForSave = (habit, idx, existing) => {
  const e = existing && typeof existing === "object" ? existing : {};
  const rawId = habit?.id ?? e.id ?? idx + 1;
  const id = Number.isFinite(Number(rawId)) ? Number(rawId) : idx + 1;
  const rawLevel = habit?.level ?? e.level ?? id;
  const level = Number.isFinite(Number(rawLevel)) ? Number(rawLevel) : id;
  return {
    id,
    level,
    title: habit?.title !== undefined ? habit.title : (e.title ?? ""),
    text: habit?.text !== undefined ? habit.text : (e.text ?? ""),
    reps:
      habit?.reps !== undefined && habit?.reps !== ""
        ? habit.reps
        : (e.reps ?? ""),
  };
};

// Helper to get form values directly from screen content (no local state)
// Uses actual keys from the structure as defined in temp2.js
const getFormValuesFromScreen = (screen) => {
  if (!screen) return {};
  const contentType = screen.screenContents?.contentType;
  const content = screen.screenContents?.content || {};

  // Use actual keys from the structure (temp2.js)
  const values = {};

  if (contentType === "content") {
    values.heading = content.heading || "";
    values.body = content.body || "";
    values.mediaUrl = content.media?.url || "";
    values.mediaType = content.media?.type || "";
    values.contentFullBleed = content.fullBleed ?? true;
    values.media = content.media || {};
  }

  if (contentType === "mcq") {
    values.title = content.title || "";
    values.question = content.question || "";
    values.top_label = content.top_label || "";
    values.bottom_label = content.bottom_label || "";
    values.keyLearning = content.keyLearning || content.key_learning || "";
    values.options = content.options || [];
  }

  if (contentType === "force_rank") {
    values.title = content.title || "";
    values.question = content.question || "";
    values.highLabel = content.highLabel || "";
    values.lowLabel = content.lowLabel || "";
    values.keyLearning = content.keyLearning || content.key_learning || "";
    values.options = content.options || [];
  }

  if (contentType === "linear") {
    values.title = content.title || "";
    values.question = content.question || "";
    values.highLabel = content.highLabel || "";
    values.lowLabel = content.lowLabel || "";
    values.key_learning = content.key_learning || "";
    values.lowerScale = content.lowerScale;
    values.higherScale = content.higherScale;
    values.linearBenchmarkType =
      content.benchmark_type || content.benchmarkType || "";
  }

  if (contentType === "reflection") {
    // Some reflection screens may still use heading/body from older schema
    values.title = content.title || content.heading || "";
    values.prompt = stripHtmlToPlainText(content.prompt || content.body || "");
  }

  if (contentType === "action" || contentType === "actions") {
    values.title = content.title || content.actionTitle || "";
    values.text = content.text || content.actionDescription || "";
    values.canSchedule = content.canSchedule ?? false;
    values.canCompleteNow = content.canCompleteNow ?? false;
    values.hasReflectionQuestion = content.hasReflectionQuestion ?? false;
    values.toolLink = content.toolLink || "";
    values.toolName = content.toolName || "";
    values.reflectionPrompt = content.reflectionPrompt || "";
    values.reflection_question = content.reflection_question || "";
    values.actionImage =
      content.ImageUrl || content.image || content.media?.url || "";
    
    // Debug logging for action screens
    console.log("🔍 Action screen values:", {
      contentType,
      content,
      extracted: {
        title: values.title,
        text: values.text,
      }
    });
  }

  if (contentType === "habits") {
    values.title = content.title || "";
    values.habitDescription = content.habitDescription || "";
    const legacyUrl =
      typeof content.habit_image === "string"
        ? content.habit_image
        : content.habit_image?.url || content.habit_image?.ImageUrl || "";
    values.habit_image =
      (typeof content.habitImage === "string" ? content.habitImage : "") ||
      legacyUrl;
    values.description =
      (typeof content.habit_image === "object" &&
        content.habit_image?.description) ||
      "";
    values.habits = content.habits || [];
  }

  if (
    contentType === "social_discussion" ||
    contentType === "socialDiscussion" ||
    contentType === "social"
  ) {
    values.title = content.title || content.heading || "";
    values.question = content.question || content.body || "";
  }

  if (contentType === "assessment") {
    values.title = content.title || "";
    values.description = content.description || "";
    values.questions = content.questions || [];
  }

  if (contentType === "notifications") {
    // Backend / path updation may use heading+body or notifications* keys (see FromDoerToEnabler)
    values.title =
      content.heading || content.notificationsTitle || content.title || "";
    values.message =
      content.body ||
      content.message ||
      content.notificationsMessage ||
      content.description ||
      "";
    values.mediaType = content.media?.type || "none";
    values.mediaUrl =
      content.media?.url ||
      (typeof content.icon === "string"
        ? content.icon
        : content.icon?.url || content.icon?.ImageUrl || "");
  }

  if (contentType === "miniapp" || contentType === "miniApp") {
    // For miniApp: title from content.heading, screen.title, or ""
    values.title = content?.heading || screen.title || "";
    // htmlContent: prefer content.html, then htmlContent, content, or string
    if (typeof content === "string") {
      values.htmlContent = content;
    } else {
      values.htmlContent =
        content?.html || content?.htmlContent || content?.content || "";
    }
  }

  if (contentType === "profile") {
    values.heading = content.heading || "";
    values.body = content.body || "";
  }

  if (contentType === "managerEmail" || contentType === "managerEmail") {
    values.heading = content.heading || "";
    values.body = content.body || "";
    values.email = content.email || "";
  }
  if (
    contentType === "accountabilityPartnerEmail" ||
    contentType === "accountabilityPartnerEmail"
  ) {
    values.heading = content.heading || "";
    values.body = content.body || "";
    values.emails = Array.isArray(content.emails) ? content.emails : [""];
  }

  if (
    contentType === "pathPersonalization" ||
    contentType === "pathpersonalization"
  ) {
    values.heading = content.heading || "";
    values.body = content.body || "";
    values.mediaType = content.media?.type || "";
    values.mediaUrl = content.media?.url || "";
    values.mediaAlt = content.media?.alt || "";
  }

  return values;
};

export default function DynamicForm({
  screen,
  sessionData,
  setAllMessages,
  setOutline,
  onClose,
  chapterNumber,
  stepNumber,
  screenNumber: screenNumberFromParent,
  isAskingKyper = false,
  setIsAskingKyper = () => {},
  onRequestAutoSave,
}) {
  // No local state - derive form values directly from screen
  const formData = useMemo(() => {
    const values = getFormValuesFromScreen(screen);
    // console.log("🟢 FormData derived from screen:", {
    //   heading: values.heading,
    //   body: values.body?.substring(0, 50) + "...",
    //   screenContent: screen?.screenContents?.content,
    // });
    return values;
  }, [screen]);

  const screenNumber = useMemo(() => {
    if (typeof screenNumberFromParent === "number" && screenNumberFromParent >= 0) {
      return screenNumberFromParent + 1;
    }
    if (typeof screen?.order === "number") return screen.order + 1;
    if (typeof screen?.position === "number") return screen.position + 1;
    return 1;
  }, [screenNumberFromParent, screen]);

  // On mount (screen opened), deduplicate image assets — keep only the last image.
  useEffect(() => {
    const screenId = screen?.id;
    const screenUuid = screen?.uuid;
    const assets = screen?.assets;
    if (!screenId || !assets || assets.length <= 1) return;

    const getUrl = (a) =>
      a?.ImageUrl || a?.image_url || a?.url || a?.mediaUrl || a?.s3_url || null;
    const isImage = (a) => Boolean(getUrl(a) && !a?.audioUrl && !a?.videoUrl);

    const imageIndices = [];
    assets.forEach((a, i) => { if (isImage(a)) imageIndices.push(i); });
    if (imageIndices.length <= 1) return;

    const indicesToRemove = new Set(imageIndices.slice(0, -1));

    setOutline((prev) => {
      if (!prev?.chapters) return prev;
      const next = JSON.parse(JSON.stringify(prev));
      for (const ch of next.chapters) {
        for (const step of ch.steps || []) {
          const si = step.screens?.findIndex(
            (s) =>
              (screenUuid && String(s?.uuid) === String(screenUuid)) ||
              String(s?.id) === String(screenId),
          );
          if (si !== undefined && si >= 0) {
            const scr = step.screens[si];
            scr.assets = (scr.assets || []).filter((_, i) => !indicesToRemove.has(i));
            step.screens[si] = { ...scr };
            return next;
          }
        }
      }
      return prev;
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen?.id]);

  const [focusedField, setFocusedField] = useState(null);
  const [fieldPosition, setFieldPosition] = useState(null);
  const [askContext, setAskContext] = useState(null);
  const selectionKeyRef = useRef(0);
  const blurTimeoutRef = useRef(null);
  const popupInteractingRef = useRef(false);
  const interactResetRef = useRef(null);

  // Update field directly in outline - use setOutline(prev => ...) to always work with latest state
  const updateField = (field, value) => {
    const screenId = screen?.id;
    const screenUuid = screen?.uuid;
    if (!screenId) return;

    setOutline((prevOutline) => {
      if (!prevOutline || !prevOutline.chapters) return prevOutline;

      const newOutline = JSON.parse(JSON.stringify(prevOutline));
      const pathChapters = newOutline.chapters || [];

      // Find the screen in the outline using latest state from prev
      for (const chapter of pathChapters) {
        for (const stepItem of chapter.steps || []) {
          const screenIndex = stepItem.screens?.findIndex(
            (s) =>
              (screenUuid && String(s?.uuid) === String(screenUuid)) ||
              String(s?.id) === String(screenId),
          );
          if (screenIndex !== undefined && screenIndex >= 0) {
            // Get current screen from latest state (prevOutline)
            const currentScreen = stepItem.screens[screenIndex];
            const contentType = currentScreen?.screenContents?.contentType;

            // Ensure screenContents and content exist
            if (!currentScreen.screenContents) {
              currentScreen.screenContents = { contentType, content: {} };
            }
            if (!currentScreen.screenContents.content) {
              currentScreen.screenContents.content = {};
            }

            // Map form fields to content structure using actual keys from temp2.js structure
            // Update directly on currentScreen since we're working with the latest state from prev
            if (contentType === "content") {
              if (field === "heading") {
                currentScreen.screenContents.content.heading = value;
              } else if (field === "body") {
                // Body is rich text HTML (valueFormat="html") - store as-is for backend
                currentScreen.screenContents.content.body = value;
              } else if (field === "mediaUrl") {
                if (!currentScreen.screenContents.content.media) {
                  currentScreen.screenContents.content.media = {};
                }
                currentScreen.screenContents.content.media.url = value;
              } else if (field === "mediaType") {
                if (!currentScreen.screenContents.content.media) {
                  currentScreen.screenContents.content.media = {};
                }
                currentScreen.screenContents.content.media.type = value;
              } else if (field === "mediaName") {
                if (!currentScreen.screenContents.content.media) {
                  currentScreen.screenContents.content.media = {};
                }
                currentScreen.screenContents.content.media.title = value;
              } else if (field === "contentFullBleed") {
                currentScreen.screenContents.content.fullBleed = value;
              }
            } else if (contentType === "action" || contentType === "actions") {
              if (field === "title") {
                currentScreen.screenContents.content.title = value;
              } else if (field === "text") {
                // Rich text HTML - store as-is for backend
                currentScreen.screenContents.content.text = value;
              } else if (field === "canSchedule") {
                currentScreen.screenContents.content.canSchedule = value;
              } else if (field === "canCompleteNow") {
                currentScreen.screenContents.content.canCompleteNow = value;
              } else if (field === "hasReflectionQuestion") {
                currentScreen.screenContents.content.hasReflectionQuestion =
                  value;
              } else if (field === "toolLink") {
                currentScreen.screenContents.content.toolLink = value;
              } else if (field === "toolName") {
                currentScreen.screenContents.content.toolName = value;
              } else if (field === "reflectionPrompt") {
                currentScreen.screenContents.content.reflectionPrompt = value;
              } else if (field === "actionImage") {
                currentScreen.screenContents.content.ImageUrl = value;
              }

              stepItem.screens[screenIndex] = {
                ...currentScreen,
                screenContents: {
                  ...currentScreen.screenContents,
                  content: {
                    ...currentScreen.screenContents.content,
                  },
                },
              };
            } else if (contentType === "mcq") {
              if (field === "title")
                currentScreen.screenContents.content.title = value;
              else if (field === "question") {
                currentScreen.screenContents.content.question = value;
              } else if (field === "top_label")
                currentScreen.screenContents.content.top_label = value;
              else if (field === "bottom_label")
                currentScreen.screenContents.content.bottom_label = value;
              else if (field === "keyLearning")
                currentScreen.screenContents.content.keyLearning = value;
              else if (field === "options") {
                const rawOptions = Array.isArray(value) ? value : [];
                const normalizedOptions = rawOptions.map((opt, index) => {
                  const parsedId =
                    typeof opt?.optionId === "number"
                      ? opt.optionId
                      : Number(opt?.optionId ?? opt?.option_id);
                  return {
                    optionId: Number.isFinite(parsedId) ? parsedId : index + 1,
                    text: opt?.text || "",
                    isCorrect:
                      opt?.isCorrect !== undefined
                        ? opt.isCorrect
                        : (opt?.is_correct ?? false),
                  };
                });
                if (
                  normalizedOptions.length > 0 &&
                  !normalizedOptions.some((opt) => opt.isCorrect === true)
                ) {
                  normalizedOptions[0] = {
                    ...normalizedOptions[0],
                    isCorrect: true,
                  };
                }
                currentScreen.screenContents.content.options = normalizedOptions;
              }

              // Keep MCQ content aligned to backend schema (camelCase only).
              delete currentScreen.screenContents.content.key_learning;
            } else if (contentType === "force_rank") {
              if (field === "title")
                currentScreen.screenContents.content.title = value;
              else if (field === "question") {
                currentScreen.screenContents.content.question = value;
              } else if (field === "highLabel")
                currentScreen.screenContents.content.highLabel = value;
              else if (field === "lowLabel")
                currentScreen.screenContents.content.lowLabel = value;
              else if (field === "keyLearning")
                currentScreen.screenContents.content.keyLearning = value;
              else if (field === "options")
                currentScreen.screenContents.content.options = value;

              delete currentScreen.screenContents.content.key_learning;
            } else if (contentType === "linear") {
              if (field === "title")
                currentScreen.screenContents.content.title = value;
              else if (field === "question") {
                currentScreen.screenContents.content.question = value;
              } else if (field === "highLabel")
                currentScreen.screenContents.content.highLabel = value;
              else if (field === "lowLabel")
                currentScreen.screenContents.content.lowLabel = value;
              else if (field === "key_learning")
                currentScreen.screenContents.content.key_learning = value;
              else if (field === "lowerScale")
                currentScreen.screenContents.content.lowerScale = value;
              else if (field === "higherScale")
                currentScreen.screenContents.content.higherScale = value;
              else if (field === "linearBenchmarkType")
                currentScreen.screenContents.content.benchmark_type = value;
            } else if (contentType === "reflection") {
              if (field === "title") {
                // Keep heading in sync with title (heading was previously only set on first
                // keystroke, which broke display anywhere heading is read before title).
                currentScreen.screenContents.content.title = value;
                currentScreen.screenContents.content.heading = value;
              } else if (field === "prompt") {
                currentScreen.screenContents.content.prompt = value;
                currentScreen.screenContents.content.body = value;
              }
            } else if (
              contentType === "social_discussion" ||
              contentType === "socialDiscussion" ||
              contentType === "social" ||
              contentType === "socialdiscussion"
            ) {
              if (field === "title") {
                currentScreen.screenContents.content.title = value;
              } else if (field === "question") {
                currentScreen.screenContents.content.question = value;
              }
              if (field === "title" || field === "question") {
                delete currentScreen.screenContents.content.heading;
                delete currentScreen.screenContents.content.body;
              }
            } else if (contentType === "assessment") {
              if (field === "title")
                currentScreen.screenContents.content.title = value;
              else if (field === "description") {
                currentScreen.screenContents.content.description = value;
              }
              else if (field === "questions") {
                if (Array.isArray(value)) {
                  currentScreen.screenContents.content.questions = value.map((question, qIdx) => {
                    const rawQuestionId =
                      typeof question?.questionId === "number"
                        ? question.questionId
                        : Number(question?.questionId ?? question?.question_id);
                    const baseOptions = Array.isArray(question?.options)
                      ? question.options
                      : [];
                    const normalizedOptions = baseOptions.map((option, oIdx) => {
                      const rawOptionId =
                        typeof option?.optionId === "number"
                          ? option.optionId
                          : Number(option?.optionId ?? option?.option_id);
                      return {
                        optionId: Number.isFinite(rawOptionId)
                          ? rawOptionId
                          : oIdx + 1,
                        text: stripHtmlToPlainText(option?.text || ""),
                      };
                    });
                    while (normalizedOptions.length < 4) {
                      normalizedOptions.push({
                        optionId: normalizedOptions.length + 1,
                        text: `Option ${normalizedOptions.length + 1}`,
                      });
                    }

                    return {
                      questionId: Number.isFinite(rawQuestionId)
                        ? rawQuestionId
                        : qIdx + 1,
                      text: stripHtmlToPlainText(question?.text || question?.question || ""),
                      options: normalizedOptions.slice(0, 5),
                    };
                  });
                } else {
                  currentScreen.screenContents.content.questions = value;
                }
              }
              // Ensure schema stays backend-compatible.
              delete currentScreen.screenContents.content.question_id;
              if (!currentScreen.screenContents.content.description) {
                currentScreen.screenContents.content.description =
                  "Measure understanding through scenario-based questions.";
              }
            } else if (contentType === "habits") {
              const c = currentScreen.screenContents.content;
              if (field === "title") c.title = value;
              else if (field === "habitDescription") {
                c.habitDescription = value;
              } else if (field === "description") {
                if (
                  c.habit_image &&
                  typeof c.habit_image === "object" &&
                  !Array.isArray(c.habit_image)
                ) {
                  c.habit_image.description = value;
                }
              } else if (field === "habit_image") {
                const url =
                  typeof value === "string"
                    ? value
                    : value?.url || value?.ImageUrl || "";
                c.habitImage = url;
                delete c.habit_image;
              } else if (field === "habits") {
                if (Array.isArray(value)) {
                  const existingHabits = c.habits || [];
                  c.habits = value.map((habit, idx) => {
                    if (habit && typeof habit === "object") {
                      const existing = existingHabits[idx] || {};
                      const nextTitle =
                        habit.title !== undefined && habit.title !== ""
                          ? habit.title
                          : (existing.title ?? "");
                      const nextReps =
                        habit.reps !== undefined && habit.reps !== ""
                          ? habit.reps
                          : (existing.reps ?? "");
                      const nextText =
                        habit.text !== undefined && habit.text !== ""
                          ? habit.text
                          : (existing.text ?? "");

                      const merged = {
                        ...existing,
                        ...habit,
                        title: nextTitle,
                        reps: nextReps,
                        text: nextText,
                      };
                      return normalizeHabitRowForSave(merged, idx, existing);
                    }
                    return habit;
                  });
                } else {
                  c.habits = value;
                }
              }
            } else if (contentType === "notifications") {
              if (field === "title") {
                currentScreen.screenContents.content.heading = value;
              } else if (field === "message") {
                currentScreen.screenContents.content.body = value;
                currentScreen.screenContents.content.message = value;
              } else if (field === "mediaType") {
                if (!currentScreen.screenContents.content.media) {
                  currentScreen.screenContents.content.media = {
                    type: "none",
                    url: "",
                  };
                }
                currentScreen.screenContents.content.media.type = value;
              } else if (field === "mediaUrl" || field === "icon") {
                if (!currentScreen.screenContents.content.media) {
                  currentScreen.screenContents.content.media = {
                    type: "image",
                    url: "",
                  };
                }
                currentScreen.screenContents.content.media.url = value;
                if (
                  currentScreen.screenContents.content.media.type === "none" &&
                  value
                ) {
                  currentScreen.screenContents.content.media.type = "image";
                }
              }
            } else if (contentType === "profile") {
              if (field === "heading") {
                currentScreen.screenContents.content.heading = value;
              } else if (field === "body") {
                currentScreen.screenContents.content.body = value;
              }
            } else if (contentType === "miniapp" || contentType === "miniApp") {
              // For miniApp: title → content.heading, htmlContent → content.html; always keep { heading, html } shape
              if (field === "title") {
                const c = currentScreen.screenContents.content;
                if (typeof c === "string") {
                  currentScreen.screenContents.content = {
                    heading: value,
                    html: c,
                  };
                } else {
                  if (!c || typeof c !== "object") {
                    currentScreen.screenContents.content = {
                      heading: value,
                      html: "",
                    };
                  } else {
                    c.heading = value;
                  }
                }
              } else if (field === "htmlContent") {
                const c = currentScreen.screenContents.content;
                if (typeof c === "string") {
                  currentScreen.screenContents.content = {
                    heading: "",
                    html: value,
                  };
                } else {
                  if (!c || typeof c !== "object") {
                    currentScreen.screenContents.content = {
                      heading: "",
                      html: value,
                    };
                  } else {
                    if (typeof c.heading !== "string") {
                      c.heading = "";
                    }
                    c.html = value;
                    delete c.htmlContent;
                  }
                }
              }
            } else if (
              contentType === "managerEmail" ||
              contentType === "managerEmail"
            ) {
              if (field === "heading") {
                currentScreen.screenContents.content.heading = value;
              } else if (field === "body") {
                currentScreen.screenContents.content.body = value;
              } else if (field === "email") {
                currentScreen.screenContents.content.email = value;
              }
            } else if (
              contentType === "accountabilityPartnerEmail" ||
              contentType === "accountabilityPartnerEmail"
            ) {
              if (field === "heading") {
                currentScreen.screenContents.content.heading = value;
              } else if (field === "body") {
                currentScreen.screenContents.content.body = value;
              } else if (field === "emails") {
                currentScreen.screenContents.content.emails = Array.isArray(
                  value,
                )
                  ? value
                  : [];
              }
            } else if (
              contentType === "pathPersonalization" ||
              contentType === "pathpersonalization"
            ) {
              if (field === "heading") {
                currentScreen.screenContents.content.heading = value;
              } else if (field === "body") {
                currentScreen.screenContents.content.body = value;
              } else if (field === "mediaType") {
                if (!currentScreen.screenContents.content.media) {
                  currentScreen.screenContents.content.media = {
                    type: "",
                    url: "",
                    alt: "",
                  };
                }
                currentScreen.screenContents.content.media.type = value;
              } else if (field === "mediaUrl") {
                if (!currentScreen.screenContents.content.media) {
                  currentScreen.screenContents.content.media = {
                    type: "",
                    url: "",
                    alt: "",
                  };
                }
                currentScreen.screenContents.content.media.url = value;
              } else if (field === "mediaAlt") {
                if (!currentScreen.screenContents.content.media) {
                  currentScreen.screenContents.content.media = {
                    type: "",
                    url: "",
                    alt: "",
                  };
                }
                currentScreen.screenContents.content.media.alt = value;
              }
            }

            // Update title for display
            if (currentScreen.screenContents.content.title) {
              currentScreen.title = currentScreen.screenContents.content.title;
            } else if (currentScreen.screenContents.content.heading) {
              currentScreen.title =
                currentScreen.screenContents.content.heading;
            }

            // Explicitly preserve assets when updating screen

            const existingAssets = currentScreen.assets || [];
            stepItem.screens[screenIndex] = {
              ...currentScreen,
              screenContents: {
                ...currentScreen.screenContents,
                content: {
                  ...currentScreen.screenContents.content,
                },
              },
              assets: existingAssets, // Preserve assets
            };

            return newOutline;
          }
        }
      }
      return prevOutline;
    });
  };

  const addListItem = (listName) => {
    const currentList = formData[listName] || [];
    updateField(listName, [...currentList, ""]);
  };

  const updateListItem = (listName, index, value) => {
    const currentList = formData[listName] || [];
    const newList = [...currentList];
    newList[index] = value;
    updateField(listName, newList);
  };

  const removeListItem = (listName, index) => {
    const currentList = formData[listName] || [];
    const newList = currentList.filter((_, i) => i !== index);
    updateField(listName, newList);
  };

  const reorderListItem = (listName, draggedIndex, dropIndex) => {
    const currentList = formData[listName] || [];
    if (draggedIndex === dropIndex || draggedIndex < 0 || dropIndex < 0) return;

    const newList = [...currentList];
    const draggedItem = newList[draggedIndex];
    newList.splice(draggedIndex, 1);
    newList.splice(dropIndex, 0, draggedItem);
    updateField(listName, newList);
  };

  const clearBlurTimeout = () => {
    if (blurTimeoutRef.current) {
      clearTimeout(blurTimeoutRef.current);
      blurTimeoutRef.current = null;
    }
  };

  const clearAskContext = () => {
    clearBlurTimeout();
    setFocusedField(null);
    setFieldPosition(null);
    setAskContext(null);
  };

  const handleFieldBlur = () => {
    // Skip if user is interacting with the popup (mousedown on popup fires before blur)
    if (popupInteractingRef.current) return;
    clearBlurTimeout();
    blurTimeoutRef.current = setTimeout(() => {
      clearAskContext();
    }, 200);
  };

  const handlePopupInteract = () => {
    clearBlurTimeout();
    // Set flag to prevent upcoming blur from dismissing the popup
    popupInteractingRef.current = true;
    clearTimeout(interactResetRef.current);
    interactResetRef.current = setTimeout(() => {
      popupInteractingRef.current = false;
    }, 500);
  };

  useEffect(() => {
    if (!focusedField) return;

    const isAskKyperPopupEvent = (event) => {
      const target = event.target;
      return target?.closest?.("[data-ask-kyper-popup]");
    };

    const shouldDismissOnKey = (event) => {
      if (
        event.ctrlKey ||
        event.metaKey ||
        event.altKey ||
        event.isComposing ||
        event.key === "Escape" ||
        event.key === "Tab" ||
        event.key.startsWith("Arrow")
      ) {
        return false;
      }

      return (
        event.key.length === 1 ||
        event.key === "Backspace" ||
        event.key === "Delete" ||
        event.key === "Enter"
      );
    };

    const handleReplaceSelection = (event) => {
      if (!shouldDismissOnKey(event)) return;

      // Keys in the Ask Kyper popup (e.g. backspace/delete on query text) must not close it.
      if (isAskKyperPopupEvent(event)) {
        return;
      }

      // Typing or editing in the form again should dismiss the popup.
      clearAskContext();
    };

    const handlePaste = (event) => {
      if (isAskKyperPopupEvent(event)) return;

      clearAskContext();
    };

    document.addEventListener("keydown", handleReplaceSelection, true);
    document.addEventListener("paste", handlePaste, true);
    return () => {
      document.removeEventListener("keydown", handleReplaceSelection, true);
      document.removeEventListener("paste", handlePaste, true);
    };
  }, [focusedField]);

  const handleTextFieldSelect = (fieldName, event, fieldValue) => {
    if (!event?.target) return;

    clearBlurTimeout();

    const input = event.target;
    const { selectionStart, selectionEnd, value } = input;
    if (
      selectionStart === null ||
      selectionEnd === null ||
      selectionStart === selectionEnd
    ) {
      clearAskContext();
      return;
    }

    const selectedText = value.substring(selectionStart, selectionEnd).trim();
    if (!selectedText) {
      clearAskContext();
      return;
    }

    const rect = input.getBoundingClientRect();
    selectionKeyRef.current += 1;
    setFocusedField(fieldName + "::" + selectionKeyRef.current);
    setFieldPosition({
      top: rect.bottom + window.scrollY + 8,
      left: rect.left + window.scrollX,
    });
    setAskContext({
      fieldName,
      selectedText,
      fieldValue,
      screenId: screen?.id,
      screenName: screen?.name || screen?.title || "",
      screenType:
        screen?.screenContents?.contentType ||
        screen?.screenType ||
        screen?.type ||
        "",
    });
  };

  const handleRichTextSelection = (fieldName, selectionInfo, fieldValue) => {
    if (!selectionInfo) {
      handleFieldBlur();
      return;
    }

    clearBlurTimeout();

    const text = (selectionInfo.text || "").trim();
    if (!text) {
      handleFieldBlur();
      return;
    }

    const position = selectionInfo.absolutePosition || {
      top: (selectionInfo.editorRect?.bottom || 0) + window.scrollY,
      left: (selectionInfo.editorRect?.left || 0) + window.scrollX,
    };

    selectionKeyRef.current += 1;
    setFocusedField(fieldName + "::" + selectionKeyRef.current);
    setFieldPosition({
      top: position.top + 8,
      left: position.left,
    });
    setAskContext({
      fieldName,
      selectedText: text,
      fieldValue,
      screenId: screen?.id,
      screenName: screen?.name || screen?.title || "",
      screenType:
        screen?.screenContents?.contentType ||
        screen?.screenType ||
        screen?.type ||
        "",
    });
  };

  // console.log(">>> sessionData", sessionData);

  const handleAskKyper = async (query) => {
    if (!askContext || !query?.trim()) return;

    try {
      setIsAskingKyper(true);

      const userMessage = query.trim();
      setAllMessages?.((prev) => [
        ...(Array.isArray(prev) ? prev : []),
        { from: "user", content: userMessage },
      ]);

      const sessionId =
        sessionData?.session_id ||
        (typeof window !== "undefined"
          ? localStorage.getItem("sessionId")
          : null);

      const fieldNameMap = {
        contentHeading: "heading",
        contentBody: "body",
        contentMediaUrl: "media.url",
        mcqTitle: "title",
        mcqQuestion: "question",
        mcqTopLabel: "top_label",
        mcqBottomLabel: "bottom_label",
        mcqKeyLearning: "key_learning",
        mcqOptions: "options",
        forceRankTitle: "title",
        forceRankHighLabel: "highLabel",
        forceRankLowLabel: "lowLabel",
        forceRankQuestion: "question",
        forceRankKeyLearning: "keyLearning",
        forceRankOptions: "options",
        linearTitle: "title",
        linearHighLabel: "highLabel",
        linearLowLabel: "lowLabel",
        linearQuestion: "question",
        linearKeyLearning: "key_learning",
        linearLowerScale: "lowerScale",
        linearHigherScale: "higherScale",
        reflectionTitle: "title",
        reflectionPrompt: "prompt",
        actionTitle: "title",
        actionText: "text",
        actionToolLink: "toolLink",
        actionReflectionPrompt: "reflectionPrompt",
        socialTitle: "title",
        socialQuestion: "question",
        assessmentTitle: "title",
        assessmentQuestions: "questions",
        habitsTitle: "title",
        habitDescription: "habitDescription",
        habitsText: "habits[].text",
        notificationsTitle: "title",
        notificationsMessage: "message",
        profileHeading: "heading",
        profileBody: "body",
        managerEmailHeading: "heading",
        managerEmailBody: "body",
        managerEmailEmail: "email",
        accountabilityPartnerHeading: "heading",
        accountabilityPartnerBody: "body",
        accountabilityPartnerEmails: "emails",
      };

      const mappedField =
        fieldNameMap[askContext.fieldName] || askContext.fieldName;

      const conversationMessage = `{ 'path': 'phase-${chapterNumber}-step-${stepNumber}-screen-${screenNumber}', 'field': '${mappedField}', 'value': '${askContext.selectedText}', 'instruction': '${query}' }`;
      console.log("conversationMessage>>", conversationMessage);

      // Merge with existing conversation history (same pattern as ChatWindow.jsx)
      const existingConversation = sessionData?.chatbot_conversation || [];
      const newEntries = [{ user: conversationMessage }];
      const chatbotConversation = [...existingConversation, ...newEntries];
      console.log("chatbotConversation>>", chatbotConversation);

      const payloadObject = JSON.stringify({
        session_id: sessionId,
        input_type: "path_updation",
        cycle_creation_data: sessionData?.cycle_creation_data || {},
        response_outline: sessionData?.response_outline || {},
        response_path: sessionData?.response_path || {},
        // additional_data: {
        //   personalization_enabled:
        //     sessionData?.additional_data?.personalization_enabled || false,
        //   habit_enabled: sessionData?.additional_data?.habit_enabled || false,
        //   habit_description:
        //     sessionData?.additional_data?.habit_description || "",
        // },
        chatbot_conversation: chatbotConversation,
        to_modify: {},
        webpage_url: sessionData?.webpage_url || [],
      });

      const messageResponse = await graphqlClient.sendMessage(payloadObject);
      console.log("messageResponse>>", messageResponse);

      if (messageResponse?.sendMessage) {
        setAllMessages?.((prev) => [
          ...(Array.isArray(prev) ? prev : []),
          // { from: "bot", content: messageResponse.sendMessage },
        ]);
      }
    } catch (error) {
      console.error("Error asking Kyper:", error);
      setIsAskingKyper(false);
    } finally {
      clearAskContext();
    }
  };

  const renderFormContent = () => {
    const screenType = (screen?.screenType || "").toLowerCase();
    const contentType = (
      screen?.screenContents?.contentType || ""
    ).toLowerCase();
    // Extract IDs for asset upload
    const sessionId =
      sessionData?.session_id ||
      (typeof window !== "undefined"
        ? localStorage.getItem("sessionId")
        : null);
    const screenId = screen?.id || "";
    const chapterId = screen?.chapterId || "";
    const stepId = screen?.stepId || "";

    // Extract UUIDs for asset upload
    const screenUuid = screen?.uuid || "";
    const stepUuid = screen?.stepUid || "";
    // Find chapter UUID from outline using stepUuid (more reliable than chapterId)
    let chapterUuid = "";
    const outline = sessionData?.response_path;
    if (outline?.chapters && stepUuid) {
      // Search through chapters to find the one containing this step
      for (const chapter of outline.chapters) {
        if (chapter.steps) {
          for (const stepItem of chapter.steps) {
            const step = stepItem?.step;
            if (step && step.uuid === stepUuid) {
              chapterUuid = chapter.uuid || "";
              break;
            }
          }
          if (chapterUuid) break;
        }
      }
    }

    // Align with ImageUpload's getAssetUrl: check all URL field variants.
    const getAssetImageUrl = (asset) =>
      asset?.ImageUrl || asset?.image_url || asset?.url || asset?.mediaUrl || asset?.s3_url || null;

    const isOutlineScreenImageAsset = (asset) =>
      Boolean(getAssetImageUrl(asset) && !asset?.audioUrl && !asset?.videoUrl);

    // Function to update screen asset
    const updateScreenAssets = (assets) => {
      const screenUuid = screen?.uuid;
      const screenId = screen?.id;
      if (!screenUuid && !screenId) return;

      setOutline((prevOutline) => {
        if (!prevOutline || !prevOutline.chapters) return prevOutline;

        const newOutline = JSON.parse(JSON.stringify(prevOutline));
        const pathChapters = newOutline.chapters || [];

        for (const chapter of pathChapters) {
          for (const stepItem of chapter.steps || []) {
            const screenIndex = stepItem.screens?.findIndex(
              (s) => (screenUuid && s.uuid === screenUuid) || (!screenUuid && s.id === screenId),
            );
            if (screenIndex !== undefined && screenIndex >= 0) {
              const currentScreen = stepItem.screens[screenIndex];
              if (!currentScreen.assets) currentScreen.assets = [];
              const existingAssets = currentScreen.assets || [];
              const incomingList = Array.isArray(assets) ? assets : [assets];
              const replacesScreenImages = incomingList.some(
                isOutlineScreenImageAsset,
              );
              const newAssets = replacesScreenImages
                ? [
                    ...existingAssets.filter((a) => !isOutlineScreenImageAsset(a)),
                    ...incomingList,
                  ]
                : [...existingAssets, ...incomingList];

              stepItem.screens[screenIndex] = {
                ...currentScreen,
                assets: newAssets,
                imageStatus: "ready",
              };

              if (replacesScreenImages) {
                const nextScreen = stepItem.screens[screenIndex];
                if (!nextScreen.screenContents) nextScreen.screenContents = {};
                if (!nextScreen.screenContents.content)
                  nextScreen.screenContents.content = {};
                if (!nextScreen.screenContents.content.media)
                  nextScreen.screenContents.content.media = {};
                nextScreen.screenContents.content.media.type = "image";
              }
              return newOutline;
            }
          }
        }
        return prevOutline;
      });
    };

    // Function to remove asset(s) from screen. Pass a single index or an array (e.g. all image indices) — arrays are applied in one update, highest index first.
    const removeScreenAsset = (assetIndexOrIndices) => {
      const screenUuid = screen?.uuid;
      const screenId = screen?.id;
      if (!screenUuid && !screenId) return;

      const rawIndices = Array.isArray(assetIndexOrIndices)
        ? assetIndexOrIndices
        : [assetIndexOrIndices];
      const indices = [...new Set(rawIndices)]
        .filter(
          (i) => typeof i === "number" && !Number.isNaN(i) && i >= 0,
        )
        .sort((a, b) => b - a);
      if (indices.length === 0) return;

      setOutline((prevOutline) => {
        if (!prevOutline || !prevOutline.chapters) return prevOutline;

        const newOutline = JSON.parse(JSON.stringify(prevOutline));
        const pathChapters = newOutline.chapters || [];

        // Find the screen in the outline and remove asset(s)
        for (const chapter of pathChapters) {
          for (const stepItem of chapter.steps || []) {
            const screenIndex = stepItem.screens?.findIndex(
              (s) => (screenUuid && s.uuid === screenUuid) || (!screenUuid && s.id === screenId),
            );
            if (screenIndex !== undefined && screenIndex >= 0) {
              const currentScreen = stepItem.screens[screenIndex];
              const existingAssets = [...(currentScreen.assets || [])];
              for (const assetIndex of indices) {
                if (assetIndex < existingAssets.length) {
                  existingAssets.splice(assetIndex, 1);
                }
              }
              stepItem.screens[screenIndex] = {
                ...currentScreen,
                assets: existingAssets,
              };
              return newOutline;
            }
          }
        }
        return prevOutline;
      });
    };

    const formProps = {
      formData,
      updateField,
      addListItem,
      updateListItem,
      removeListItem,
      reorderListItem,
      updateScreenAssets,
      removeScreenAsset,
      screen,
      sessionId,
      chapterId,
      stepId,
      screenId,
      chapterUuid,
      stepUuid,
      screenUuid,
      onRequestAutoSave,
      chapterNumber,
      stepNumber,
      screenNumber,
    };

    //1-Content
    if (screenType === "content" || contentType === "content") {
      return (
        <ContentForm
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
            onRichTextSelection: handleRichTextSelection,
            onRichTextBlur: handleFieldBlur,
          }}
        />
      );
    }

    //2-Poll
    if (
      screenType === "poll" ||
      ["mcq", "linear", "force_rank"].includes(contentType)
    ) {
      if (contentType === "mcq")
        return (
          <PollMcqForm
            {...formProps}
            askKyperHandlers={{
              onTextFieldSelect: handleTextFieldSelect,
              onFieldBlur: handleFieldBlur,
              onRichTextSelection: handleRichTextSelection,
              onRichTextBlur: handleFieldBlur,
            }}
          />
        );
      if (contentType === "linear")
        return (
          <PollLinearForm
            {...formProps}
            askKyperHandlers={{
              onTextFieldSelect: handleTextFieldSelect,
              onFieldBlur: handleFieldBlur,
              onRichTextSelection: handleRichTextSelection,
              onRichTextBlur: handleFieldBlur,
            }}
          />
        );
      if (contentType === "force_rank")
        return (
          <ForceRankForm
            {...formProps}
            askKyperHandlers={{
              onTextFieldSelect: handleTextFieldSelect,
              onFieldBlur: handleFieldBlur,
              onRichTextSelection: handleRichTextSelection,
              onRichTextBlur: handleFieldBlur,
            }}
          />
        );
    }

    //3-Habits
    if (screenType === "habits" || contentType === "habits") {
      return (
        <HabitOptInForm
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
            onRichTextSelection: handleRichTextSelection,
            onRichTextBlur: handleFieldBlur,
          }}
        />
      );
    }

    //4-Reflection
    if (screenType === "reflection" || contentType === "reflection") {
      return (
        <ReflectionForm
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
            onRichTextSelection: handleRichTextSelection,
            onRichTextBlur: handleFieldBlur,
          }}
        />
      );
    }

    console.log("ACTIONSSSS", screenType, contentType);
    //5-Actions
    if (
      screenType === "action" ||
      screenType === "actions" ||
      contentType === "action" ||
      contentType === "actions"
    ) {
      return (
        <ActionsForm
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
            onRichTextSelection: handleRichTextSelection,
            onRichTextBlur: handleFieldBlur,
          }}
        />
      );
    }
    console.log("AFTERRRRRR");
    //6-Social Discussion
    if (
      screenType === "social" ||
      contentType === "social_discussion" ||
      contentType === "socialDiscussion"
    ) {
      return (
        <SocialDiscussionForm
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
            onRichTextSelection: handleRichTextSelection,
            onRichTextBlur: handleFieldBlur,
          }}
        />
      );
    }

    if (screenType === "assessment" || contentType === "assessment") {
      return (
        <AssessmentForm
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
            onRichTextSelection: handleRichTextSelection,
            onRichTextBlur: handleFieldBlur,
          }}
        />
      );
    }

    //7-Notifications
    if (screenType === "notifications" || contentType === "notifications") {
      return (
        <NotificationsForm
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
            onRichTextSelection: handleRichTextSelection,
            onRichTextBlur: handleFieldBlur,
          }}
        />
      );
    }

    //8-MiniApp (HTML content in iframe)
    if (
      screenType === "miniapp" ||
      contentType === "miniapp" ||
      screen?.screenType === "miniApp" ||
      screen?.screenContents?.contentType === "miniApp"
    ) {
      return (
        <MiniAppForm
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
          }}
        />
      );
    }

    //9-Profile
    if (screenType === "profile" || contentType === "profile") {
      return (
        <ProfileForm
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
            onRichTextSelection: handleRichTextSelection,
            onRichTextBlur: handleFieldBlur,
          }}
        />
      );
    }

    //Manager Email & Accountability Partner Email
    const isManagerEmail =
      screenType === "managerEmail" ||
      contentType === "managerEmail" ||
      screenType === "managerEmail" ||
      contentType === "managerEmail" ||
      screenType === "manageremail" ||
      contentType === "manageremail";
    if (isManagerEmail) {
      return (
        <EmailPromptForm
          formTitle="Manager Email"
          fieldPrefix="managerEmail"
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
            onRichTextSelection: handleRichTextSelection,
            onRichTextBlur: handleFieldBlur,
          }}
        />
      );
    }
    const isAccountabilityPartnerEmail =
      screenType === "accountabilityPartnerEmail" ||
      contentType === "accountabilityPartnerEmail" ||
      screenType === "accountabilitypartneremail" ||
      contentType === "accountabilitypartneremail";
    if (isAccountabilityPartnerEmail) {
      return (
        <AccountabilityPartnerEmailForm
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
            onRichTextSelection: handleRichTextSelection,
            onRichTextBlur: handleFieldBlur,
          }}
        />
      );
    }

    // Path Personalization
    if (
      screenType === "path_personalization" ||
      contentType === "pathPersonalization" ||
      contentType === "pathpersonalization"
    ) {
      return (
        <PathPersonalizationForm
          {...formProps}
          askKyperHandlers={{
            onTextFieldSelect: handleTextFieldSelect,
            onFieldBlur: handleFieldBlur,
            onRichTextSelection: handleRichTextSelection,
            onRichTextBlur: handleFieldBlur,
          }}
        />
      );
    }

    return (
      <div className="p-2">
        <p className="text-sm text-gray-600">
          No form available for this screen type:{" "}
          {formatContentTypeLabel(screen?.screenType, "unknown")} /{" "}
          {formatContentTypeLabel(screen?.screenContents?.contentType, "unknown")}
        </p>
      </div>
    );
  };

  return (
    <div className="bg-white h-fit rounded-t-md no-scrollbar overflow-auto">
      {/* <div className="p-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <h3 className="font-medium text-primary text-xl">{screen.name}</h3>
        </div>
        {renderEaseCategories()}
      </div> */}
      <div className="p-2">{renderFormContent()}</div>
      <AskKyperPopup
        focusedField={focusedField}
        fieldPosition={fieldPosition}
        isLoading={isAskingKyper}
        onClose={clearAskContext}
        onAskKyper={handleAskKyper}
        onPopupInteract={handlePopupInteract}
      />
    </div>
  );
}
